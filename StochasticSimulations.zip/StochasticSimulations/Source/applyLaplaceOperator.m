%=========================================================================%
% This function applies the Laplace operator with boundary conditions to  %
% the vector F.                                                         %
%=========================================================================%

function laplaceF = applyLaplaceOperator(F, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, ...
                               beta, beta2, s1Vec, s1Vec2, etaGrad2, betaTimesEtax, betaTimesEtay, betaTimesEtaLaplace)

% Compute Fs and Fss
Fs  = reshape(reshape(F, [2*Nx*2*Ny, Ns+1])*Ds1, [2*Nx*2*Ny*(Ns+1),1]);
Fss = reshape(reshape(F, [2*Nx*2*Ny, Ns+1])*Ds2, [2*Nx*2*Ny*(Ns+1), 1]);

% Compute Fxx, Fyy, Fsx and Fsy
Fxx = reshape(ifft(Dx2.*fft(reshape(F, [2*Nx, 2*Ny*(Ns+1)]))),  [2*Nx*2*Ny*(Ns+1),1]);
Fsx = reshape(ifft(Dx1.*fft(reshape(Fs, [2*Nx, 2*Ny*(Ns+1)]))), [2*Nx*2*Ny*(Ns+1),1]);
Fyy = reshape(ifft(fft(reshape(F, [2*Nx, 2*Ny, Ns+1]), 2*Ny, 2).*Dy2, 2*Ny, 2), [2*Nx*2*Ny*(Ns+1),1]);
Fsy = reshape(ifft(fft(reshape(Fs, [2*Nx, 2*Ny, Ns+1]), 2*Ny, 2).*Dy1, 2*Ny, 2), [2*Nx*2*Ny*(Ns+1),1]);

%=========================================================================%
% Compute the part of laplaceF having to do with the differential         %
% equation i.e. the inner M-1 s points.                                   %
%=========================================================================%

laplaceF = reshape(beta2.*(reshape(Fxx, [2*Nx*2*Ny, Ns+1]) + reshape(Fyy, [2*Nx*2*Ny, Ns+1])), [2*Nx*2*Ny*(Ns+1), 1]) ...
            + 4*Fss ...
            + reshape(etaGrad2.*reshape(Fss, [2*Nx*2*Ny, Ns+1]).*s1Vec2, [2*Nx*2*Ny*(Ns+1), 1]) ...
            - 2*reshape((betaTimesEtax.*reshape(Fsx, [2*Nx*2*Ny, Ns+1]) + betaTimesEtay.*reshape(Fsy, [2*Nx*2*Ny, Ns+1])).*s1Vec, [2*Nx*2*Ny*(Ns+1),1]) ...
            + 2*reshape(etaGrad2.*reshape(Fs, [2*Nx*2*Ny, Ns+1]).*s1Vec, [2*Nx*2*Ny*(Ns+1), 1]) ...
            - reshape((betaTimesEtaLaplace.*reshape(Fs, [2*Nx*2*Ny, Ns+1])).*s1Vec, [2*Nx*2*Ny*(Ns+1), 1]);

%=========================================================================%
% Compute the part of laplaceF having to do with the boundary conditions  %
% at s = -1 and s = 1                                                     %
%=========================================================================%

% Add the part containing the boundary condition at s = -1 to laplaceF
laplaceF(1:2*Nx*2*Ny) = 2./beta.*Fs(1:2*Nx*2*Ny) - reshape(ifft(transpose(ifft(fft(transpose(fft(reshape(F(1:2*Nx*2*Ny), [2*Nx, 2*Ny])))).*TMat))), [2*Nx*2*Ny, 1]);

% Add the part containing the boundary condition at s = 1 to laplaceF
laplaceF(2*Nx*2*Ny*Ns+1:2*Nx*2*Ny*(Ns+1)) = F(2*Nx*2*Ny*Ns+1:2*Nx*2*Ny*(Ns+1));

end        