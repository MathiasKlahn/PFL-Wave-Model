%=========================================================================%
% This function computes all three components of the fluid velocity at    %
% the surface.                                                            % 
%=========================================================================%

function [uSurf, vSurf, wSurf] = compSurfVel(y, Nx, Ny, M, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, s1Vec, s1Vec2,...
                                 b, epsGMRES, decompL, decompU, decompP)

% Compute etax, etay and etaGrad2
etax = reshape(ifft(Dx1.*fft(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]))), [2*Nx*2*Ny, 1]);
etay = reshape(ifft(fft(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]), 2*Ny, 2).*Dy1, 2*Ny, 2), [2*Nx*2*Ny, 1]);
etaGrad2 = etax.^2 + etay.^2;

                             
% Compute b+eta, (b+eta)^2, and etaxx+etayy
beta  = b + y(1:2*Nx*2*Ny);
beta2 = beta.^2;
etaLaplace = reshape(ifft(Dx2.*fft(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]))), [2*Nx*2*Ny, 1]) ...
             + reshape(ifft(fft(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]), 2*Ny, 2).*Dy2, 2*Ny, 2), [2*Nx*2*Ny, 1]);         
                  
% Compute (b+eta)*etax, (b+eta)*detady and beta*(etaxx+etayy)
betaTimesEtax       = beta.*etax;
betaTimesEtay       = beta.*etay;
betaTimesEtaLaplace = beta.*etaLaplace;

% Construct the right hand side vector for the Laplace equation
rhsVec = zeros(2*Nx*2*Ny*(M+1), 1);
rhsVec(2*Nx*2*Ny*M+1:2*Nx*2*Ny*(M+1)) = y(2*Nx*2*Ny+1:2*2*Nx*2*Ny);
    
% Construct handles for the laplace operator and the preconditioner
laplaceOperatorHandle = @(F) applyLaplaceOperator(F, Nx, Ny, M, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, ...
                             beta, beta2, s1Vec, s1Vec2, etaGrad2, betaTimesEtax, betaTimesEtay, betaTimesEtaLaplace);
preconHandle = @(F) applyPrecon(F, Nx, Ny, M, decompL, decompU, decompP);

% Solve the Laplace equation and take the real part of F to make sure that
% F is real!
F = gmres(laplaceOperatorHandle, rhsVec, [], epsGMRES, 10, preconHandle);
F = real(F);

% Compute derivatives of F
Fx  = reshape(ifft(Dx1.*fft(reshape(F, [2*Nx, 2*Ny*(M+1)]))), [2*Nx*2*Ny*(M+1),1]);
Fy  = reshape(ifft(fft(reshape(F, [2*Nx, 2*Ny, M+1]), 2*Ny, 2).*Dy1, 2*Ny, 2), [2*Nx*2*Ny*(M+1),1]);
Fs  = reshape(reshape(F, [2*Nx*2*Ny, M+1])*Ds1, [2*Nx*2*Ny*(M+1),1]);

% Compute the velocities in the upper part of the domain
u  = reshape(Fx - reshape(((etax./beta).*reshape(Fs, [2*Nx*2*Ny, M+1])).*s1Vec, [2*Nx*2*Ny*(M+1),1]), [2*Nx*2*Ny, M+1]);
v  = reshape(Fy - reshape(((etay./beta).*reshape(Fs, [2*Nx*2*Ny, M+1])).*s1Vec, [2*Nx*2*Ny*(M+1),1]), [2*Nx*2*Ny, M+1]);
w  = reshape(((2./beta).*reshape(Fs, [2*Nx*2*Ny, M+1])), [2*Nx*2*Ny, M+1]);

% Extract the surface velocities
uSurf = u(:,end);
vSurf = v(:,end);
wSurf = w(:,end);

end      