%=========================================================================%
% This function computes the matrices KMat and TMat.                      %
%=========================================================================%

function [KMat, TMat, DMat] = constructKMatTMatDMat(Nx, Ny, Lx, Ly, kp, h, b)

% Define parameters for the artificial damping
beta1 = 8;
beta2 = 30;

% Construct lists containing the values of kx and ky
kxList = 2*pi/Lx*[0:Nx, -Nx+1:-1];
kyList = 2*pi/Ly*[0:Ny, -Ny+1:-1];

% Compute TMat and KMat
TMat = zeros(2*Nx, 2*Ny);
KMat = zeros(2*Nx, 2*Ny);
DMat = ones(2*Nx, 2*Ny);

if h == inf
    for px = 1:2*Nx
        for py = 1:2*Ny
            k = sqrt(kxList(px)^2 + kyList(py)^2);
            KMat(px, py) = k;
            TMat(px, py) = k;
            DMat(px, py) = exp(-(k/(beta1*kp))^beta2);
        end
    end
else
    for px = 1:2*Nx
        for py = 1:2*Ny
            k = sqrt(kxList(px)^2 + kyList(py)^2);
            KMat(px, py) = k;
            TMat(px, py) = k*tanh(k*(h-b));
            DMat(px, py) = exp(-(k/(beta1*kp))^beta2);
        end
    end
end

% Transpose TMat
TMat = transpose(TMat);


end