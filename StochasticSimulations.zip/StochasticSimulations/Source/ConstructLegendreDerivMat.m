%=========================================================================%
% This function computes the 1st and 2nd s derivative matrices. NOTE that %
% the matrices are TRANSPOSED when outputed!!                             %
%=========================================================================%

function [Ds1, Ds2] = ConstructLegendreDerivMat(Ns, sgrid)


% Compute the barycentric weights
BarWts = ones(Ns+1,1);
for m = 1:Ns+1
    for i = 1:m-1
        BarWts(m) = BarWts(m)*(sgrid(m) - sgrid(i));
    end
    
    for i = m+1:Ns+1
        BarWts(m) = BarWts(m)*(sgrid(m) - sgrid(i));
    end
end
BarWts = 1./BarWts;


% Construct the 1st order derivative matrix
Ds1 = zeros(Ns+1, Ns+1);
for i = 1:Ns+1
    % Fill in the (i,j)th element of Ds1 with j<i
    for j = 1:i-1
        Ds1(i,j) = BarWts(j)/(BarWts(i)*(sgrid(i) - sgrid(j))); 
    end     
    
    % Fill in the (i,j)th element of Ds1 with j>i
    for j = i+1:Ns+1
        Ds1(i,j) = BarWts(j)/(BarWts(i)*(sgrid(i) - sgrid(j))); 
    end
    
    % Fill in the (i,i)th element of Ds1
    Ds1(i,i) = -(sum(Ds1(i,1:i-1)) + sum(Ds1(i,i+1:Ns+1)));
end


% Construct the 2nd order derivative matrix
Ds2 = zeros(Ns+1, Ns+1);
for i = 1:Ns+1
    % Fill in the (i,j)th element of Ds2 with j<i
    for j = 1:i-1
        Ds2(i,j) = 2/(sgrid(i) - sgrid(j))*(BarWts(j)/BarWts(i)*Ds1(i,i) - Ds1(i,j));
    end
    
    % Fill in the (i,j)th element of Ds2 with j>i
    for j = i+1:Ns+1
        Ds2(i,j) = 2/(sgrid(i) - sgrid(j))*(BarWts(j)/BarWts(i)*Ds1(i,i) - Ds1(i,j));
    end
    
    % Fill in the (i,i)th element of Ds2
    Ds2(i,i) = -(sum(Ds2(i,1:i-1)) + sum(Ds2(i,i+1:Ns+1)));
end


% Transpose Ds1 and Ds2
Ds1 = transpose(Ds1);
Ds2 = transpose(Ds2);


end