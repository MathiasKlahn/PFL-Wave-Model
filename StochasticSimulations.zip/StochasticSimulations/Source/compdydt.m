%=========================================================================%
% This function computes dydt.                                            %
%=========================================================================%

function dydt = compdydt(y, t, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, s1Vec, s1Vec2, b, g,...
    epsGMRES, decompL, decompU, decompP, Fguess, KMat, tAdjust, nAdjust)

% Compute etax, etay, etaGrad2, Phisx and Phisy
etax = reshape(ifft(Dx1.*fft(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]))), [2*Nx*2*Ny, 1]);
etay = reshape(ifft(fft(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]), 2*Ny, 2).*Dy1, 2*Ny, 2), [2*Nx*2*Ny, 1]);
etaGrad2 = etax.^2 + etay.^2;

Phisx = reshape(ifft(Dx1.*fft(reshape(y(2*Nx*2*Ny+1:2*2*Nx*2*Ny), [2*Nx, 2*Ny]))), [2*Nx*2*Ny, 1]);
Phisy = reshape(ifft(fft(reshape(y(2*Nx*2*Ny+1:2*2*Nx*2*Ny), [2*Nx, 2*Ny]), 2*Ny, 2).*Dy1, 2*Ny, 2), [2*Nx*2*Ny, 1]);

% Compute w0 and ws
w0 = reshape(ifft2(KMat.*fft2(reshape(y(2*Nx*2*Ny+1:2*2*Nx*2*Ny), [2*Nx, 2*Ny]))), [2*Nx*2*Ny,1]);
ws = compws(y, etax, etay, etaGrad2, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, s1Vec, s1Vec2, b, ...
            epsGMRES, decompL, decompU, decompP, Fguess);

% Compute dydt
dydt = zeros(2*2*Nx*2*Ny, 1);
dydt(1:2*Nx*2*Ny) = w0 + ((1 + etaGrad2).*ws - (etax.*Phisx + etay.*Phisy) - w0)*(1-exp(-(t/tAdjust)^nAdjust));
dydt(2*Nx*2*Ny+1:2*2*Nx*2*Ny) = -g*y(1:2*Nx*2*Ny) + (-1/2*(Phisx.^2 + Phisy.^2) + 1/2*ws.^2.*(1 + etaGrad2))*(1-exp(-(t/tAdjust)^nAdjust));

end                                                                          