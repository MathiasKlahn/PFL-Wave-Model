%=========================================================================%
% This function computes the preconditioning matrix PMat and its LUP      %
% decomposition.                                                          %
%=========================================================================%

function [decompL, decompU, decompP] = compLUPrecon(Nx, Ny, Ns, Ds1, Ds2, KMat, TMatTrans, b)

% Compute -(KMat*b)^2
minusKMatb2 = reshape(-(KMat*b).^2, [2*Nx*2*Ny, 1]);

% Construct the matrix representation of the preconditioning operation
iList    = zeros(2*Nx*2*Ny*(Ns+1)*(Ns+3),1);       % iList contains the row indices of the nonzeros of PMat
jList    = zeros(2*Nx*2*Ny*(Ns+1)*(Ns+3),1);       % jList contains the column indices of the nonzeros of PMat
vList    = zeros(2*Nx*2*Ny*(Ns+1)*(Ns+3),1);       % vList contains the nonzero values of the PMat
nNonZero = 1;                                      % nNonZero is the "absolute index" of a nonzero (i.e. first nonzero, second nonzero, ...)

nx = 1;
ny = 1;
ns = 1;
for p = 1:2*Nx*2*Ny*(Ns+1)
    % Add the part containing Fss
    for m = 2:Ns
        iList(nNonZero) = nx+2*Nx*(ny-1)+2*Nx*2*Ny*(m-1);
        jList(nNonZero) = p;
        vList(nNonZero) = 4*Ds2(ns,m);
        nNonZero = nNonZero + 1;
    end
    
    % Add the part containing nabla2F
    if 2 < ns && ns < Ns+1 
        iList(nNonZero) = nx+2*Nx*(ny-1)+2*Nx*2*Ny*(ns-1);
        jList(nNonZero) = p;
        vList(nNonZero) = minusKMatb2(nx+2*Nx*(ny-1));
        nNonZero = nNonZero + 1;
    end
    
    % Add the part containing the boundary condition at s = -1
    iList(nNonZero) = nx+2*Nx*(ny-1);
    jList(nNonZero) = p;
    vList(nNonZero) = 2/b*Ds1(ns,1);
    nNonZero = nNonZero + 1;
    if ns == 1
        iList(nNonZero) = nx+2*Nx*(ny-1);
        jList(nNonZero) = p;
        vList(nNonZero) = - TMatTrans(nx + 2*Nx*(ny-1));
        nNonZero = nNonZero + 1;
    end
    
        
    % Add the part containing the boundary condition at s = 1
    if ns == Ns+1
        iList(nNonZero) = nx+2*Nx*(ny-1)+2*Nx*2*Ny*Ns;
        jList(nNonZero) = p;
        vList(nNonZero) = 1;
        nNonZero = nNonZero + 1;
    end
    
     
    % Update nx, ny and ns
    if mod(p, 2*Nx*2*Ny) == 0
        nx = 1;
        ny = 1;
        ns = ns+1;
    elseif mod(p, 2*Nx) == 0 && mod(p, 2*Nx*2*Ny) ~= 0
        nx = 1;
        ny = ny+1;
    else
        nx = nx+1;
    end
end

% Fill in PMat using iList, jList and vList
PMat = sparse(iList(1:find(iList, 1, 'last')), jList(1:find(iList, 1, 'last')), vList(1:find(iList, 1, 'last')));


% Compute the LUP decomposition of PMat
[decompL, decompU, decompP] = lu(PMat);


end 