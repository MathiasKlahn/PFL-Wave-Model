%=========================================================================%
% This function computes the vertical profile of the standard deviation   %
% of all three components of the fluid acceleration.                      % 
%=========================================================================%

function [axStd, ayStd, azStd] = compAccStdProfile(y, zGrid, g, h, b, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, KMat, ...
                                                   TMat, s1Vec, s1Vec2, epsGMRES, decompL, decompU, decompP)

% Compute etax, etay, etaGrad2 Phisx and Phisy
etax = reshape(ifft(Dx1.*fft(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]))), [2*Nx*2*Ny, 1]);
etay = reshape(ifft(fft(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]), 2*Ny, 2).*Dy1, 2*Ny, 2), [2*Nx*2*Ny, 1]);
etaGrad2 = etax.^2 + etay.^2;
                   
Phisx = reshape(ifft(Dx1.*fft(reshape(y(2*Nx*2*Ny+1:2*2*Nx*2*Ny), [2*Nx, 2*Ny]))), [2*Nx*2*Ny, 1]);
Phisy = reshape(ifft(fft(reshape(y(2*Nx*2*Ny+1:2*2*Nx*2*Ny), [2*Nx, 2*Ny]), 2*Ny, 2).*Dy1, 2*Ny, 2), [2*Nx*2*Ny, 1]);

% Compute b+eta, (b+eta)^2, and etaxx+etayy
beta  = b + y(1:2*Nx*2*Ny);
beta2 = beta.^2;
etaLaplace = reshape(ifft(Dx2.*fft(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]))), [2*Nx*2*Ny, 1]) ...
             + reshape(ifft(fft(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]), 2*Ny, 2).*Dy2, 2*Ny, 2), [2*Nx*2*Ny, 1]);         
                  
% Compute (b+eta)*etax, (b+eta)*detady and beta*(etaxx+etayy)
betaTimesEtax       = beta.*etax;
betaTimesEtay       = beta.*etay;
betaTimesEtaLaplace = beta.*etaLaplace;

%=========================================================================%
% SOLVE THE LAPLACE PROBLEM FOR F.                                        %
%=========================================================================%

% Construct the right hand side vector for the Laplace equation
rhsVec = zeros(2*Nx*2*Ny*(Ns+1), 1);
rhsVec(2*Nx*2*Ny*Ns+1:2*Nx*2*Ny*(Ns+1)) = y(2*Nx*2*Ny+1:2*2*Nx*2*Ny);
    
% Construct handles for the laplace operator and the preconditioner
laplaceOperatorHandle = @(F) applyLaplaceOperator(F, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, ...
                             beta, beta2, s1Vec, s1Vec2, etaGrad2, betaTimesEtax, betaTimesEtay, betaTimesEtaLaplace);
preconHandle = @(F) applyPrecon(F, Nx, Ny, Ns, decompL, decompU, decompP);

% Solve the Laplace equation and take the real part of F to make sure that
% F is real!
F = gmres(laplaceOperatorHandle, rhsVec, [], epsGMRES, 10, preconHandle);
F = real(F);

%=========================================================================%
% SOLVE THE LAPLACE PROBLEM FOR Ft.                                       %
%=========================================================================%

% Compute ws
ws = 2./beta.*(reshape(F, [2*Nx*2*Ny, Ns+1])*Ds1(:,Ns+1));

% Compute etat and Phist
etat  = (1 + etaGrad2).*ws - (etax.*Phisx + etay.*Phisy);
Phist = -g*y(1:2*Nx*2*Ny) - 1/2*(Phisx.^2 + Phisy.^2) + 1/2*ws.^2.*(1 + etaGrad2);

% Construct the right hand side vector for the Laplace equation
rhsVec = zeros(2*Nx*2*Ny*(Ns+1), 1);
rhsVec(2*Nx*2*Ny*Ns+1:2*Nx*2*Ny*(Ns+1)) = Phist - ws.*etat;

% Solve the Laplace equation and take the real part of Ft to make sure that
% Ft is real!
Ft = gmres(laplaceOperatorHandle, rhsVec, [], epsGMRES, 10, preconHandle);
Ft = real(Ft);

%=========================================================================%
% COMPUTE THE SPATIAL DERIVATIVES OF F AND Ft.                            %
%=========================================================================%

% Compute derivatives of F
Fx  = reshape(ifft(Dx1.*fft(reshape(F, [2*Nx, 2*Ny*(Ns+1)]))), [2*Nx*2*Ny*(Ns+1),1]);
Fy  = reshape(ifft(fft(reshape(F, [2*Nx, 2*Ny, Ns+1]), 2*Ny, 2).*Dy1, 2*Ny, 2), [2*Nx*2*Ny*(Ns+1),1]);
Fs  = reshape(reshape(F, [2*Nx*2*Ny, Ns+1])*Ds1, [2*Nx*2*Ny*(Ns+1),1]);

% Compute the velocity components u, v and w
u  = reshape(Fx - reshape(((etax./beta).*reshape(Fs, [2*Nx*2*Ny, Ns+1])).*s1Vec, [2*Nx*2*Ny*(Ns+1),1]), [2*Nx, 2*Ny, Ns+1]);
v  = reshape(Fy - reshape(((etay./beta).*reshape(Fs, [2*Nx*2*Ny, Ns+1])).*s1Vec, [2*Nx*2*Ny*(Ns+1),1]), [2*Nx, 2*Ny, Ns+1]);
w  = reshape(((2./beta).*reshape(Fs, [2*Nx*2*Ny, Ns+1])), [2*Nx, 2*Ny, Ns+1]);

% Compute the spatial derivatives of u
uxTilde = reshape(ifft(Dx1.*fft(reshape(u, [2*Nx, 2*Ny*(Ns+1)]))), [2*Nx*2*Ny*(Ns+1),1]);
uyTilde = reshape(ifft(fft(reshape(u, [2*Nx, 2*Ny, Ns+1]), 2*Ny, 2).*Dy1, 2*Ny, 2), [2*Nx*2*Ny*(Ns+1),1]);
usTilde = reshape(reshape(u, [2*Nx*2*Ny, Ns+1])*Ds1, [2*Nx*2*Ny*(Ns+1),1]);

ux = reshape(uxTilde - reshape(((etax./beta).*reshape(usTilde, [2*Nx*2*Ny, Ns+1])).*s1Vec, [2*Nx*2*Ny*(Ns+1),1]), [2*Nx, 2*Ny, Ns+1]);
uy = reshape(uyTilde - reshape(((etay./beta).*reshape(usTilde, [2*Nx*2*Ny, Ns+1])).*s1Vec, [2*Nx*2*Ny*(Ns+1),1]), [2*Nx, 2*Ny, Ns+1]);
uz = reshape(((2./beta).*reshape(usTilde, [2*Nx*2*Ny, Ns+1])), [2*Nx, 2*Ny, Ns+1]);

% Compute the spatial derivatives of v
vxTilde = reshape(ifft(Dx1.*fft(reshape(v, [2*Nx, 2*Ny*(Ns+1)]))), [2*Nx*2*Ny*(Ns+1),1]); 
vyTilde = reshape(ifft(fft(reshape(v, [2*Nx, 2*Ny, Ns+1]), 2*Ny, 2).*Dy1, 2*Ny, 2), [2*Nx*2*Ny*(Ns+1),1]);
vsTilde = reshape(reshape(v, [2*Nx*2*Ny, Ns+1])*Ds1, [2*Nx*2*Ny*(Ns+1),1]);

vx = reshape(vxTilde - reshape(((etax./beta).*reshape(vsTilde, [2*Nx*2*Ny, Ns+1])).*s1Vec, [2*Nx*2*Ny*(Ns+1),1]), [2*Nx, 2*Ny, Ns+1]);
vy = reshape(vyTilde - reshape(((etay./beta).*reshape(vsTilde, [2*Nx*2*Ny, Ns+1])).*s1Vec, [2*Nx*2*Ny*(Ns+1),1]), [2*Nx, 2*Ny, Ns+1]);
vz = reshape(((2./beta).*reshape(vsTilde, [2*Nx*2*Ny, Ns+1])), [2*Nx, 2*Ny, Ns+1]);

% Compute the spatial derivatives of w
wxTilde = reshape(ifft(Dx1.*fft(reshape(w, [2*Nx, 2*Ny*(Ns+1)]))), [2*Nx*2*Ny*(Ns+1),1]); 
wyTilde = reshape(ifft(fft(reshape(w, [2*Nx, 2*Ny, Ns+1]), 2*Ny, 2).*Dy1, 2*Ny, 2), [2*Nx*2*Ny*(Ns+1),1]);
wsTilde = reshape(reshape(w, [2*Nx*2*Ny, Ns+1])*Ds1, [2*Nx*2*Ny*(Ns+1),1]);

wx = reshape(wxTilde - reshape(((etax./beta).*reshape(wsTilde, [2*Nx*2*Ny, Ns+1])).*s1Vec, [2*Nx*2*Ny*(Ns+1),1]), [2*Nx, 2*Ny, Ns+1]);
wy = reshape(wyTilde - reshape(((etay./beta).*reshape(wsTilde, [2*Nx*2*Ny, Ns+1])).*s1Vec, [2*Nx*2*Ny*(Ns+1),1]), [2*Nx, 2*Ny, Ns+1]);
wz = reshape(((2./beta).*reshape(wsTilde, [2*Nx*2*Ny, Ns+1])), [2*Nx, 2*Ny, Ns+1]);

% Compute the spatial derivatives of Ft and compute ut, vt and wt
Ftx = reshape(ifft(Dx1.*fft(reshape(Ft, [2*Nx, 2*Ny*(Ns+1)]))), [2*Nx*2*Ny*(Ns+1),1]);
Fty = reshape(ifft(fft(reshape(Ft, [2*Nx, 2*Ny, Ns+1]), 2*Ny, 2).*Dy1, 2*Ny, 2), [2*Nx*2*Ny*(Ns+1),1]);
Fts = reshape(reshape(Ft, [2*Nx*2*Ny, Ns+1])*Ds1, [2*Nx*2*Ny*(Ns+1),1]);

ut = reshape(Ftx - reshape(((etax./beta).*reshape(Fts, [2*Nx*2*Ny, Ns+1])).*s1Vec, [2*Nx*2*Ny*(Ns+1),1]), [2*Nx, 2*Ny, Ns+1]);
vt = reshape(Fty - reshape(((etay./beta).*reshape(Fts, [2*Nx*2*Ny, Ns+1])).*s1Vec, [2*Nx*2*Ny*(Ns+1),1]), [2*Nx, 2*Ny, Ns+1]);
wt = reshape(((2./beta).*reshape(Fts, [2*Nx*2*Ny, Ns+1])), [2*Nx, 2*Ny, Ns+1]);

%=========================================================================%
% COMPUTE THE STANDARD DEVIATIONS OF ax, ay AND az.                       %
%=========================================================================%

% Define coshMat and sinhMat
if h < inf
    coshMat = cosh(KMat*(h-b));
    sinhMat = sinh(KMat*(h-b));
end

% Compute the standard deviation of ax on the z grid
axStd = zeros(length(zGrid),1);

uCoef = fft2(reshape(u(:,:,1), [2*Nx, 2*Ny]));
vCoef = fft2(reshape(v(:,:,1), [2*Nx, 2*Ny]));
wCoef = fft2(reshape(w(:,:,1), [2*Nx, 2*Ny]));

utCoef  = fft2(reshape(ut(:,:,1), [2*Nx, 2*Ny]));
uxCoef  = fft2(reshape(ux(:,:,1), [2*Nx, 2*Ny]));
uyCoef  = fft2(reshape(uy(:,:,1), [2*Nx, 2*Ny]));
uzCoef  = fft2(reshape(uz(:,:,1), [2*Nx, 2*Ny]));
for n = 1:length(zGrid)
    if h == inf
        uEval = reshape(ifft2(uCoef.*exp(KMat*(zGrid(n) + b))), [2*Nx, 2*Ny]);
        vEval = reshape(ifft2(vCoef.*exp(KMat*(zGrid(n) + b))), [2*Nx, 2*Ny]);
        wEval = reshape(ifft2(wCoef.*exp(KMat*(zGrid(n) + b))), [2*Nx, 2*Ny]);
        
        utEval = reshape(ifft2(utCoef.*exp(KMat*(zGrid(n) + b))), [2*Nx, 2*Ny]);
        uxEval = reshape(ifft2(uxCoef.*exp(KMat*(zGrid(n) + b))), [2*Nx, 2*Ny]);
        uyEval = reshape(ifft2(uyCoef.*exp(KMat*(zGrid(n) + b))), [2*Nx, 2*Ny]);
        uzEval         = reshape(ifft2(uzCoef.*exp(KMat*(zGrid(n) + b))), [2*Nx, 2*Ny]);
    else
        uEval = reshape(ifft2(uCoef.*cosh(KMat*(h+zGrid(n)))./coshMat), [2*Nx, 2*Ny]);
        vEval = reshape(ifft2(vCoef.*cosh(KMat*(h+zGrid(n)))./coshMat), [2*Nx, 2*Ny]);
    
        wCoefMod      = wCoef.*sinh(KMat*(h+zGrid(n)))./sinhMat;
        wCoefMod(1,1) = 0;
        wEval         = reshape(ifft2(wCoefMod), [2*Nx, 2*Ny]);
    
        utEval = reshape(ifft2(utCoef.*cosh(KMat*(h+zGrid(n)))./coshMat), [2*Nx, 2*Ny]);
        uxEval = reshape(ifft2(uxCoef.*cosh(KMat*(h+zGrid(n)))./coshMat), [2*Nx, 2*Ny]);
        uyEval = reshape(ifft2(uyCoef.*cosh(KMat*(h+zGrid(n)))./coshMat), [2*Nx, 2*Ny]);
    
        uzCoefMod      = uzCoef.*sinh(KMat*(h+zGrid(n)))./sinhMat;
        uzCoefMod(1,1) = 0;
        uzEval         = reshape(ifft2(uzCoefMod), [2*Nx, 2*Ny]);
    end
    axMean   = sum(sum(utEval + uEval.*uxEval + vEval.*uyEval + wEval.*uzEval))/(2*Nx*2*Ny);
    axStd(n) = sqrt( sum(sum((utEval + uEval.*uxEval + vEval.*uyEval + wEval.*uzEval).^2))/(2*Nx*2*Ny) - axMean^2 );
end


% Compute the standard deviation of ay on the z grid
ayStd = zeros(length(zGrid),1);

vtCoef  = fft2(reshape(vt(:,:,1), [2*Nx, 2*Ny]));
vxCoef  = fft2(reshape(vx(:,:,1), [2*Nx, 2*Ny]));
vyCoef  = fft2(reshape(vy(:,:,1), [2*Nx, 2*Ny]));
vzCoef  = fft2(reshape(vz(:,:,1), [2*Nx, 2*Ny]));
for n = 1:length(zGrid)
    if h == inf
        uEval = reshape(ifft2(uCoef.*exp(KMat*(zGrid(n)+b))), [2*Nx, 2*Ny]);
        vEval = reshape(ifft2(vCoef.*exp(KMat*(zGrid(n)+b))), [2*Nx, 2*Ny]);
        wEval = reshape(ifft2(wCoef.*exp(KMat*(zGrid(n)+b))), [2*Nx, 2*Ny]);
    
        vtEval = reshape(ifft2(vtCoef.*exp(KMat*(zGrid(n)+b))), [2*Nx, 2*Ny]);
        vxEval = reshape(ifft2(vxCoef.*exp(KMat*(zGrid(n)+b))), [2*Nx, 2*Ny]);
        vyEval = reshape(ifft2(vyCoef.*exp(KMat*(zGrid(n)+b))), [2*Nx, 2*Ny]);
        vzEval = reshape(ifft2(vzCoef.*exp(KMat*(zGrid(n)+b))), [2*Nx, 2*Ny]);
    else
        uEval = reshape(ifft2(uCoef.*cosh(KMat*(h+zGrid(n)))./coshMat), [2*Nx, 2*Ny]);
        vEval = reshape(ifft2(vCoef.*cosh(KMat*(h+zGrid(n)))./coshMat), [2*Nx, 2*Ny]);
    
        wCoefMod      = wCoef.*sinh(KMat*(h+zGrid(n)))./sinhMat;
        wCoefMod(1,1) = 0;
        wEval         = reshape(ifft2(wCoefMod), [2*Nx, 2*Ny]);
    
        vtEval = reshape(ifft2(vtCoef.*cosh(KMat*(h+zGrid(n)))./coshMat), [2*Nx, 2*Ny]);
        vxEval = reshape(ifft2(vxCoef.*cosh(KMat*(h+zGrid(n)))./coshMat), [2*Nx, 2*Ny]);
        vyEval = reshape(ifft2(vyCoef.*cosh(KMat*(h+zGrid(n)))./coshMat), [2*Nx, 2*Ny]);
    
        vzCoefMod      = vzCoef.*sinh(KMat*(h+zGrid(n)))./sinhMat;
        vzCoefMod(1,1) = 0;
        vzEval         = reshape(ifft2(vzCoefMod), [2*Nx, 2*Ny]);
    end
    ayMean   = sum(sum(vtEval + uEval.*vxEval + vEval.*vyEval + wEval.*vzEval))/(2*Nx*2*Ny);
    ayStd(n) = sqrt( sum(sum((vtEval + uEval.*vxEval + vEval.*vyEval + wEval.*vzEval).^2))/(2*Nx*2*Ny) - ayMean^2 );
end



% Compute the standard deviation of ay on the z grid
azStd = zeros(length(zGrid),1);

wtCoef  = fft2(reshape(wt(:,:,1), [2*Nx, 2*Ny]));
wxCoef  = fft2(reshape(wx(:,:,1), [2*Nx, 2*Ny]));
wyCoef  = fft2(reshape(wy(:,:,1), [2*Nx, 2*Ny]));
wzCoef  = fft2(reshape(wz(:,:,1), [2*Nx, 2*Ny]));
for n = 1:length(zGrid)
    if h == inf
        uEval = reshape(ifft2(uCoef.*exp(KMat*(zGrid(n)+b))), [2*Nx, 2*Ny]);
        vEval = reshape(ifft2(vCoef.*exp(KMat*(zGrid(n)+b))), [2*Nx, 2*Ny]);
        wEval = reshape(ifft2(wCoef.*exp(KMat*(zGrid(n)+b))), [2*Nx, 2*Ny]);
    
        wtEval = reshape(ifft2(wtCoef.*exp(KMat*(zGrid(n)+b))), [2*Nx, 2*Ny]);
        wxEval = reshape(ifft2(wxCoef.*exp(KMat*(zGrid(n)+b))), [2*Nx, 2*Ny]);
        wyEval = reshape(ifft2(wyCoef.*exp(KMat*(zGrid(n)+b))), [2*Nx, 2*Ny]);
        wzEval = reshape(ifft2(wzCoef.*exp(KMat*(zGrid(n)+b))), [2*Nx, 2*Ny]);
    else
        uEval = reshape(ifft2(uCoef.*cosh(KMat*(h+zGrid(n)))./coshMat), [2*Nx, 2*Ny]);
        vEval = reshape(ifft2(vCoef.*cosh(KMat*(h+zGrid(n)))./coshMat), [2*Nx, 2*Ny]);
    
        wCoefMod      = wCoef.*sinh(KMat*(h+zGrid(n)))./sinhMat;
        wCoefMod(1,1) = 0;
        wEval         = reshape(ifft2(wCoefMod), [2*Nx, 2*Ny]);
    
        wtCoefMod      = wtCoef.*sinh(KMat*(h+zGrid(n)))./sinhMat;
        wtCoefMod(1,1) = 0;
        wtEval         = reshape(ifft2(wtCoefMod), [2*Nx, 2*Ny]); 
    
        wxCoefMod      = wxCoef.*sinh(KMat*(h+zGrid(n)))./sinhMat;
        wxCoefMod(1,1) = 0;
        wxEval         = reshape(ifft2(wxCoefMod), [2*Nx, 2*Ny]);
    
        wyCoefMod      = wyCoef.*sinh(KMat*(h+zGrid(n)))./sinhMat;
        wyCoefMod(1,1) = 0;
        wyEval         = reshape(ifft2(wyCoefMod), [2*Nx, 2*Ny]);
    
        wzEval         = reshape(ifft2(wzCoef.*cosh(KMat*(h+zGrid(n)))./coshMat), [2*Nx, 2*Ny]);
    end
    azMean   = sum(sum(wtEval + uEval.*wxEval + vEval.*wyEval + wEval.*wzEval))/(2*Nx*2*Ny);
    azStd(n) = sqrt( sum(sum((wtEval + uEval.*wxEval + vEval.*wyEval + wEval.*wzEval).^2))/(2*Nx*2*Ny) - azMean^2 );
end



end  