%=========================================================================%
% This function computes the vertical profile of the standard deviation   %
% of all three components of the fluid velocity.                          % 
%=========================================================================%

function [uStd, vStd, wStd] = compVelStdProfile(y, zGrid, h, b, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, KMat, TMat, ...
                                                s1Vec, s1Vec2, epsGMRES, decompL, decompU, decompP)

% Compute etax, etay and etaGrad2
etax = reshape(ifft(Dx1.*fft(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]))), [2*Nx*2*Ny, 1]);
etay = reshape(ifft(fft(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]), 2*Ny, 2).*Dy1, 2*Ny, 2), [2*Nx*2*Ny, 1]);
etaGrad2 = etax.^2 + etay.^2;
                             
% Compute b+eta, (b+eta)^2, and etaxx+etayy
beta  = b + y(1:2*Nx*2*Ny);
beta2 = beta.^2;
etaLaplace = reshape(ifft(Dx2.*fft(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]))), [2*Nx*2*Ny, 1]) ...
             + reshape(ifft(fft(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]), 2*Ny, 2).*Dy2, 2*Ny, 2), [2*Nx*2*Ny, 1]);         
                  
% Compute (b+eta)*etax, (b+eta)*detady and beta*(etaxx+etayy)
betaTimesEtax       = beta.*etax;
betaTimesEtay       = beta.*etay;
betaTimesEtaLaplace = beta.*etaLaplace;

% Construct the right hand side vector for the Laplace equation
rhsVec = zeros(2*Nx*2*Ny*(Ns+1), 1);
rhsVec(2*Nx*2*Ny*Ns+1:2*Nx*2*Ny*(Ns+1)) = y(2*Nx*2*Ny+1:2*2*Nx*2*Ny);
    
% Construct handles for the laplace operator and the preconditioner
laplaceOperatorHandle = @(F) applyLaplaceOperator(F, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, ...
                             beta, beta2, s1Vec, s1Vec2, etaGrad2, betaTimesEtax, betaTimesEtay, betaTimesEtaLaplace);
preconHandle = @(F) applyPrecon(F, Nx, Ny, Ns, decompL, decompU, decompP);

% Solve the Laplace equation and take the real part of F to make sure that
% F is real!
F = gmres(laplaceOperatorHandle, rhsVec, [], epsGMRES, 10, preconHandle);
F = real(F);

% Compute derivatives of F
Fx  = reshape(ifft(Dx1.*fft(reshape(F, [2*Nx, 2*Ny*(Ns+1)]))), [2*Nx*2*Ny*(Ns+1),1]);
Fy  = reshape(ifft(fft(reshape(F, [2*Nx, 2*Ny, Ns+1]), 2*Ny, 2).*Dy1, 2*Ny, 2), [2*Nx*2*Ny*(Ns+1),1]);
Fs  = reshape(reshape(F, [2*Nx*2*Ny, Ns+1])*Ds1, [2*Nx*2*Ny*(Ns+1),1]);

% Compute the velocities in the upper part of the domain
u  = reshape(Fx - reshape(((etax./beta).*reshape(Fs, [2*Nx*2*Ny, Ns+1])).*s1Vec, [2*Nx*2*Ny*(Ns+1),1]), [2*Nx, 2*Ny, Ns+1]);
v  = reshape(Fy - reshape(((etay./beta).*reshape(Fs, [2*Nx*2*Ny, Ns+1])).*s1Vec, [2*Nx*2*Ny*(Ns+1),1]), [2*Nx, 2*Ny, Ns+1]);
w  = reshape(((2./beta).*reshape(Fs, [2*Nx*2*Ny, Ns+1])), [2*Nx, 2*Ny, Ns+1]);

% Compute the standard deviation of u, v and w on the z grid
uStd = zeros(length(zGrid),1);
vStd = zeros(length(zGrid),1);
wStd = zeros(length(zGrid),1);

uCoef = fft2(reshape(u(:,:,1), [2*Nx, 2*Ny]));
vCoef = fft2(reshape(v(:,:,1), [2*Nx, 2*Ny]));
wCoef = fft2(reshape(w(:,:,1), [2*Nx, 2*Ny]));

if h < inf
    coshMat = cosh(KMat*(h-b));
    sinhMat = sinh(KMat*(h-b));
end

for n = 1:length(zGrid)
    if h == inf
        uEval = reshape(ifft2(uCoef.*exp(KMat*(zGrid(n)+b))), [2*Nx, 2*Ny]);
        vEval = reshape(ifft2(vCoef.*exp(KMat*(zGrid(n)+b))), [2*Nx, 2*Ny]);
        wEval = reshape(ifft2(wCoef.*exp(KMat*(zGrid(n)+b))), [2*Nx, 2*Ny]);
    else
        uEval = reshape(ifft2(uCoef.*cosh(KMat*(h+zGrid(n)))./coshMat), [2*Nx, 2*Ny]);
        vEval = reshape(ifft2(vCoef.*cosh(KMat*(h+zGrid(n)))./coshMat), [2*Nx, 2*Ny]);
    
        wCoefMod      = wCoef.*sinh(KMat*(h+zGrid(n)))./sinhMat;
        wCoefMod(1,1) = 0;
        wEval         = reshape(ifft2(wCoefMod), [2*Nx, 2*Ny]);
    end
    uMean = sum(sum(uEval))/(2*Nx*2*Ny);
    vMean = sum(sum(vEval))/(2*Nx*2*Ny);
    wMean = sum(sum(wEval))/(2*Nx*2*Ny);
    
    
    uStd(n) = sqrt(sum(sum((uEval - uMean).^2))/(2*Nx*2*Ny));
    vStd(n) = sqrt(sum(sum((vEval - vMean).^2))/(2*Nx*2*Ny));
    wStd(n) = sqrt(sum(sum((wEval - wMean).^2))/(2*Nx*2*Ny));
end


end  