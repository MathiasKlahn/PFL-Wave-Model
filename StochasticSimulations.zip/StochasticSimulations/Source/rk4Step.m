%=========================================================================%
% This function advances y one time step using the classical 4th order    %
% Runge Kutta method.                                                     %
%=========================================================================%

function ynew = rk4Step(yold, tNonDim, deltatDim, deltatNonDim, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, s1Vec, s1Vec2, b, g, ...
    epsGMRES, decompL, decompU, decompP, DMat, KMat, tAdjust, nAdjust)


% Load global variables
global Fold

% Compute k1, k2, k3 and k4
k1 = deltatDim*compdydt(yold, tNonDim, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, s1Vec, s1Vec2, b, g,...
                     epsGMRES, decompL, decompU, decompP, Fold(:,1), KMat, tAdjust, nAdjust);      
k2 = deltatDim*compdydt(yold+k1/2, tNonDim+0.5*deltatNonDim, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, s1Vec, s1Vec2, b, g,...
                     epsGMRES, decompL, decompU, decompP, 2*Fold(:,1)-Fold(:,3), KMat, tAdjust, nAdjust);
k3 = deltatDim*compdydt(yold+k2/2, tNonDim+0.5*deltatNonDim, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, s1Vec, s1Vec2, b, g,...
                     epsGMRES, decompL, decompU, decompP, Fold(:,1), KMat, tAdjust, nAdjust);
k4 = deltatDim*compdydt(yold+k3, tNonDim+deltatNonDim, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, s1Vec, s1Vec2, b, g,...
                     epsGMRES, decompL, decompU, decompP, 2*Fold(:,1)-Fold(:,3), KMat, tAdjust, nAdjust);

                 
% Compute ynew and apply damping
ynew = yold + 1/6*(k1 + 2*k2 + 2*k3 + k4);
ynew(1:2*Nx*2*Ny)             = reshape(ifft2(DMat.*fft2(reshape(ynew(1:2*Nx*2*Ny), [2*Nx, 2*Ny]))), [2*Nx*2*Ny, 1]);
ynew(2*Nx*2*Ny+1:2*2*Nx*2*Ny) = reshape(ifft2(DMat.*fft2(reshape(ynew(2*Nx*2*Ny+1:2*2*Nx*2*Ny), [2*Nx, 2*Ny]))), [2*Nx*2*Ny, 1]);

end