clc; close all; clear all;

%=========================================================================%
% 1) ADD DIRECTORIES TO THE SEARCH PATH.                                  %
%=========================================================================%

% Add the source directory to the search path
addpath('')

%=========================================================================%
% 2) DEFINE NONDIMENSIONAL PHYSICAL PARAMETERS AND PARAMETERS FOR THE     %
%    SPATIAL RESOLUTION.                                                  %
%=========================================================================%

% Define dimensionless parameters of the wave field
kph   = 2;       % Peak wave number times water depth
steep = 0.000001;  % Wave steepness (steep = 2*kp*<eta^2>^(1/2))
ND    = 2;         % Parameter for the directional distribution
gamma = 3.3;       % Peak enhancement factor

% Define the dimensionless size of the computational domain
lx = 50;                 % The domain size in the x-direction in units of peak wavelengths
ly = (1+ND)^(1/2)*lx;    % The domain size in the y-direction in units of peak wavelengths

% Define parameters related to the spatial resolution
Nx = 128;       % 2*Nx is the number of points used in the x-direction
Ny = 128;       % 2*Ny is the number of points used in the y-direction
Ns = 5;         % Ns+1 is the number of points used in the vertical dimension

% Define parameters related to the time integration
NPeriod = 5;    % The number of peak periods for which the wave field is integrated in time
NStep   = 50;    % The number of time steps per peak period

%=========================================================================%
% 3) COMPUTE THE SKEWNESS AND KURTOSIS AS FUNCTIONS OF TIME.              %
%=========================================================================%

skewness = zeros(NPeriod*NStep,1);
kurtosis = zeros(NPeriod*NStep,1);
for nPeriod = 1:NPeriod
    % Load the moments of the surface elevations for the current period
    moments = dlmread(['OutputData/etaMomentsSteep', num2str(1000000*steep), 'kph', num2str(10*kph), 'ND', num2str(ND), ...
                       'Time', num2str(nPeriod), 'Nx', num2str(Nx), 'Ny', num2str(Ny), 'Ns', num2str(Ns), 'NStep', num2str(NStep)]);
                
    % Normalize the moments
    etaRMS  = moments(:,2).^(1/2);
    moments = moments./[etaRMS.^2, etaRMS.^2, etaRMS.^3, etaRMS.^4];
        
    % Add the moments to the average moments
    skewness((nPeriod-1)*NStep+1:nPeriod*NStep) = moments(:,3);
    kurtosis((nPeriod-1)*NStep+1:nPeriod*NStep) = moments(:,4);
end

% Construct the time list (in units of peak periods)
timeList = (0:NStep*NPeriod-1)/NStep;

%=========================================================================%
% 4) PLOT THE RESULT OF THE COMPUTATION.                                  %
%=========================================================================%

% Plot the skewness as a function of time
figure(1)
plot(timeList, skewness, 'LineWidth', 2)

set(gca, 'FontSize', 16)
set(gca, 'TickLabelInterpreter', 'latex')
set(gca, 'position', [0.16, 0.20, 0.80, 0.76])
   
xlabel('$t/T_p$', 'interpreter', 'latex', 'FontSize', 22)
ylabel('$\mathcal{S}$', 'interpreter', 'latex', 'FontSize', 22)

% Plot the kurtosis as a function of time
figure(2)
plot(timeList, kurtosis, 'LineWidth', 2)

set(gca, 'FontSize', 16)
set(gca, 'TickLabelInterpreter', 'latex')
set(gca, 'position', [0.16, 0.20, 0.80, 0.76])
   
xlabel('$t/T_p$', 'interpreter', 'latex', 'FontSize', 22)
ylabel('$\mathcal{K}$', 'interpreter', 'latex', 'FontSize', 22)

