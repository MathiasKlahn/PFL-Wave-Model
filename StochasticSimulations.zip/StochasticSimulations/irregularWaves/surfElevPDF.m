clc; close all; clear all;

%=========================================================================%
% 1) ADD DIRECTORIES TO THE SEARCH PATH.                                  %
%=========================================================================%

% Add the source directory to the search path
addpath('')

%=========================================================================%
% 2) DEFINE NONDIMENSIONAL PHYSICAL PARAMETERS AND PARAMETERS FOR THE     %
%    SPATIAL RESOLUTION.                                                  %
%=========================================================================%

% Define the time of analysis in units of peak periods
time  = 0;

% Define dimensionless parameters of the wave field
kph   = 2;         % Peak wave number times water depth
steep = 0.000001;  % Wave steepness (steep = 2*kp*<eta^2>^(1/2))
ND    = 2;         % Parameter for the directional distribution
gamma = 3.3;       % Peak enhancement factor

% Define the dimensionless size of the computational domain
lx       = 50;                 % The domain size in the x-direction in units of peak wavelengths
ly       = (1+ND)^(1/2)*lx;    % The domain size in the y-direction in units of peak wavelengths

% Define parameters related to the spatial resolution
Nx = 512;        % 2*Nx is the number of points used in the x-direction
Ny = 512;        % 2*Ny is the number of points used in the y-direction
Ns = 5;          % Ns+1 is the number of points used in the vertical dimension

% Define parameters related to the time integration
NStep   = 50;    % The number of time steps per peak period

%=========================================================================%
% 3) DEFINE PHYSICAL PARAMETERS IN SI UNITS.                              %
%=========================================================================%

% Define fundamental physical scales in SI units
g       = 9.81;                % Gravitational acceleration
lambdap = 275;                 % Peak wavelength [m]

% Calculate relevant physical scales of the wave field in SI units
kp     = 2*pi/lambdap;              % Peak wave number
omegap = (g*kp*tanh(kph))^(1/2);    % Peak frequency
h      = kph/kp;                    % Water depth

% Calculate relevant physical scales of the computational domain
Lx = lx*lambdap;
Ly = ly*lambdap;

%=========================================================================%
% 4) COMPARE THE PDF OF THE INITIAL SURFACE ELEVATION WITH THE            %
%    THEORETICALLY EXPECTED PDF.                                          %
%=========================================================================%

% Load data from file
y = dlmread(['OutputData/ySteep', num2str(1000000*steep), 'kph', num2str(10*kph), 'ND', num2str(ND), ...
             'Time', num2str(time), 'Nx', num2str(Nx), 'Ny', num2str(Ny), 'Ns', num2str(Ns), ...
             'NStep', num2str(NStep)]);

% Extract the surface elevation in units of (steep*lambdap)/(4*pi)
eta = y(1:2*Nx*2*Ny)*(4*pi)/(steep*lambdap);
         
% Compare the PDF of eta with a standard normal distribution
xiList = linspace(-5, 5, 1000);

figure(1)
histogram(eta, 40, 'Norm', 'pdf')
hold on
plot(xiList, 1/sqrt(2*pi)*exp(-0.5*xiList.^2), 'LineWidth', 2)
set(gca, 'YScale', 'log')

set(gca, 'FontSize', 16)
set(gca, 'TickLabelInterpreter', 'latex')
set(gca, 'position', [0.16, 0.20, 0.80, 0.76])
   
xticks(-5:5)

xlabel('$\eta/(\varepsilon \lambda_p)$', 'interpreter', 'latex', 'FontSize', 22)
ylabel('$p\big( \eta/(\varepsilon \lambda_p) \big)$', 'interpreter', 'latex', 'FontSize', 22)

legend1 = legend('Simulation', 'Theory')
set(legend1, 'Interpreter', 'latex', 'FontSize', 14)
