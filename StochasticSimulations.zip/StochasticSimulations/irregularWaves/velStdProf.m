clc; close all; clear all;

%=========================================================================%
% 1) ADD DIRECTORIES TO THE SEARCH PATH.                                  %
%=========================================================================%

% Add the source directory to the search path
addpath('')

%=========================================================================%
% 2) DEFINE NONDIMENSIONAL PHYSICAL PARAMETERS AND PARAMETERS FOR THE     %
%    SPATIAL RESOLUTION.                                                  %
%=========================================================================%

% Define the time of analysis in units of peak periods
time  = 0;

% Define dimensionless parameters of the wave field
kph   = 2;       % Peak wave number times water depth
steep = 0.000001;  % Wave steepness (steep = 2*kp*<eta^2>^(1/2))
ND    = 2;         % Parameter for the directional distribution
gamma = 3.3;       % Peak enhancement factor

% Define the dimensionless grid of z-points (in units of 1/kp) at which the
% standard deviation of the velocity components are calcualted. Note that 
% the largest point in the grid should lie below the artificial boundary 
% condition at z = -b.
if kph == inf
    kpzGrid = linspace(-5, -0.1, 20);
else
    kpzGrid = linspace(-kph, -kph/10, 20);
end

% Define the dimensionless size of the computational domain
lx = 50;                 % The domain size in the x-direction in units of peak wavelengths
ly = (1+ND)^(1/2)*lx;    % The domain size in the y-direction in units of peak wavelengths

% Define parameters related to the spatial resolution
Nx = 512;       % 2*Nx is the number of points used in the x-direction
Ny = 512;       % 2*Ny is the number of points used in the y-direction
Ns = 5;         % Ns+1 is the number of points used in the vertical dimension

% Define parameters related to the time integration
NStep   = 50;    % The number of time steps per peak period

% Define other computational parameters
bCoef    = 1.5;      % b is computed as bCoef*Hs
epsGMRES = 1E-9;     % The relative tolerance to which the linear system for the potential is solved

%=========================================================================%
% 2) DEFINE PHYSICAL PARAMETERS IN SI UNITS.                              %
%=========================================================================%

% Define fundamental physical scales in SI units
g       = 9.81;                % Gravitational acceleration
lambdap = 275;                 % Peak wavelength [m]

% Calculate relevant physical scales of the wave field in SI units
kp     = 2*pi/lambdap;              % Peak wave number
omegap = (g*kp*tanh(kph))^(1/2);    % Peak frequency
h      = kph/kp;                    % Water depth
v0     = steep*sqrt(g/kp);          % Fundamental unit of velocity
Hs     = steep*lambdap/pi;       % Significant wave height

% Calculate relevant physical scales of the computational domain
Lx = lx*lambdap;
Ly = ly*lambdap;
b  = bCoef*Hs;

%=========================================================================%
% 3) CONSTRUCT TIME INDEPENDENT VECTORS AND MATRICES ONCE AND FOR ALL    %
%=========================================================================%

% Construct derivative vectors for the x direction
Dx1 = 1i*2*pi/Lx*[transpose(0:Nx-1); 0; transpose(-Nx+1:-1)];
Dx2 = -(2*pi/Lx*[transpose(0:Nx); transpose(-Nx+1:-1)]).^2;

% Construct derivative vectors for the y direction
Dy1 = 1i*2*pi/Ly*[0:Ny-1, 0, -Ny+1:-1];
Dy2 = -(2*pi/Ly*[0:Ny, -Ny+1:-1]).^2;

% Construct the differentiation matrices for the vertical direction
sGrid  = JacobiGL(0 ,0, Ns);
s1Vec  = transpose(1 + sGrid);
s1Vec2 = s1Vec.^2; 
[Ds1, Ds2] = ConstructLegendreDerivMat(Ns, sGrid);

% Construct KMat, TMat, DMat and the LU decomposition of the preconditioner
[KMat, TMat, DMat] = constructKMatTMatDMat(Nx, Ny, Lx, Ly, kp, h, b);
[decompL, decompU, decompP] = compLUPrecon(Nx, Ny, Ns, Ds1, Ds2, KMat, transpose(TMat), b);


%=========================================================================%
% 4) COMPUTE THE FLUID VELOCITY IN THE x AND y DIRECTIONS AT THE SURFACE. %                                                           %
%=========================================================================%

% Load data from file
y = dlmread(['OutputData/ySteep', num2str(1000000*steep), 'kph', num2str(10*kph), 'ND', num2str(ND), ...
             'Time', num2str(time), 'Nx', num2str(Nx), 'Ny', num2str(Ny), 'Ns', num2str(Ns), ...
             'NStep', num2str(NStep)]);

% Compute the standard deviation of the components of the fluid velocity at
% at the z grid in units of v0
zGrid = kpzGrid/kp;
[vxStdNum, vyStdNum, vzStdNum] = compVelStdProfile(y, zGrid, h, b, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, KMat, TMat, ...
                                                   s1Vec, s1Vec2, epsGMRES, decompL, decompU, decompP);
                                               
vxStdNum = vxStdNum/v0;
vyStdNum = vyStdNum/v0;
vzStdNum = vzStdNum/v0;

%=========================================================================%
% 5) COMPUTE THE PDF OF THE FLUID VELOCITY IN THE x AND y DIRECTIONS AT   %
%    THE SURFACE USING LINEAR THEORY.                                     %
%=========================================================================%

% Compute the cut-off frequency in units of omegap
kmax   = ((2*pi*Nx/Lx)^2 + (2*pi*Ny/Ly)^2)^(1/2);
omegaC = ((kmax/kp)*tanh(kmax*h)/tanh(kph))^(1/2);

% Define the functions S1 and S2
S1Func  = @(x) x.^(-5).*exp(-5/4*x.^(-4)).*gamma.^exp(-(x-1).^2/(2*0.07^2));
S2Func  = @(x) x.^(-5).*exp(-5/4*x.^(-4)).*gamma.^exp(-(x-1).^2/(2*0.09^2));

% Compute the standard deviations of the components of the fluid velocities
% as a function of depth
kpzGridTheo = linspace(kpzGrid(1), kpzGrid(end), 100);
vxStdTheo   = zeros(length(kpzGridTheo),1);
vyStdTheo   = zeros(length(kpzGridTheo),1);
vzStdTheo   = zeros(length(kpzGridTheo),1);
for n = 1:length(kpzGridTheo)
    % Extract the current value of kpz and define the current expFuncs
    kpz = kpzGridTheo(n);
    expFunc1 = @(x) cosh(kappaFunc(x,kph)*(kpz+kph))./sinh(kappaFunc(x,kph)*kph);
    expFunc2 = @(x) sinh(kappaFunc(x,kph)*(kpz+kph))./sinh(kappaFunc(x,kph)*kph);
    
    % Compute the necessary integrals
    I1 = integral(@(x) S1Func(x), 0, 1) + integral(@(x) S2Func(x), 1, omegaC);
    if kph == inf
        I2 = integral(@(x) S1Func(x).*x.^2.*exp(2*x.^2*kpz), 0.0000001, 1) ...
             + integral(@(x) S2Func(x).*x.^2.*exp(2*x.^2*kpz), 1, omegaC);
        I3 = I2; 
    else
        I2 = integral(@(x) S1Func(x).*x.^2.*expFunc1(x).^2, 0.0000001, 1) ...
             + integral(@(x) S2Func(x).*x.^2.*expFunc1(x).^2, 1, omegaC);
        I3 = integral(@(x) S1Func(x).*x.^2.*expFunc2(x).^2, 0.0000001, 1) ...
             + integral(@(x) S2Func(x).*x.^2.*expFunc2(x).^2, 1, omegaC); 
    end
    
    % Compute the standard deviations in units of v0
    vxStdTheo(n) = sqrt(0.25*(1+ND)/(2+ND)*tanh(kph)*I2/I1);
    vyStdTheo(n) = sqrt(0.25/(2+ND)*tanh(kph)*I2/I1);
    vzStdTheo(n) = sqrt(0.25*tanh(kph)*I3/I1);
end

%=========================================================================%
% 6) COMPARE THE NUMERICAL AND THEORETICAL RESULTS.                       %
%=========================================================================% 

% Compare the standard deviation for the x direction
figure(1)
plot(vxStdTheo, kpzGridTheo, 'LineWidth', 2)
hold on
plot(vxStdNum, kpzGrid, 'o', 'LineWidth', 2)

set(gca, 'FontSize', 16)
set(gca, 'TickLabelInterpreter', 'latex')
set(gca, 'position', [0.16, 0.20, 0.80, 0.76])
   
xlabel('$\big( \langle u^2 \rangle - \langle u \rangle^2 \big)^{1/2}/u_0$', 'interpreter', 'latex', 'FontSize', 22)
ylabel('$k_p z$', 'interpreter', 'latex', 'FontSize', 22)

legend1 = legend('Theory', 'Simulation')
set(legend1, 'Interpreter', 'latex', 'FontSize', 14, 'Location', 'southeast')

% Compare the standard deviation for the y direction
figure(2)
plot(vyStdTheo, kpzGridTheo, 'LineWidth', 2)
hold on
plot(vyStdNum, kpzGrid, 'o', 'LineWidth', 2)

set(gca, 'FontSize', 16)
set(gca, 'TickLabelInterpreter', 'latex')
set(gca, 'position', [0.16, 0.20, 0.80, 0.76])
   
xlabel('$\big( \langle v^2 \rangle - \langle v \rangle^2 \big)^{1/2}/u_0$', 'interpreter', 'latex', 'FontSize', 22)
ylabel('$k_p z$', 'interpreter', 'latex', 'FontSize', 22)

legend1 = legend('Theory', 'Simulation')
set(legend1, 'Interpreter', 'latex', 'FontSize', 14, 'Location', 'southeast')

% Compare the standard deviation for the z direction
figure(3)
plot(vzStdTheo, kpzGridTheo, 'LineWidth', 2)
hold on
plot(vzStdNum, kpzGrid, 'o', 'LineWidth', 2)

set(gca, 'FontSize', 16)
set(gca, 'TickLabelInterpreter', 'latex')
set(gca, 'position', [0.16, 0.20, 0.80, 0.76])
   
xlabel('$\big( \langle w^2 \rangle - \langle w \rangle^2 \big)^{1/2}/u_0$', 'interpreter', 'latex', 'FontSize', 22)
ylabel('$k_p z$', 'interpreter', 'latex', 'FontSize', 22)

legend1 = legend('Theory', 'Simulation')
set(legend1, 'Interpreter', 'latex', 'FontSize', 14, 'Location', 'southeast')


% This  solves the linear dispersion relation for kappa
function kappa = kappaFunc(x, kph)

% Solve the linear dispersion relation for kappa
kappa = zeros(size(x));
for n = 1:length(kappa(:))
    kappa(n) = fzero(@(y) x(n).^2.*tanh(kph) - y*tanh(y*kph), x(n).^2);
end

end