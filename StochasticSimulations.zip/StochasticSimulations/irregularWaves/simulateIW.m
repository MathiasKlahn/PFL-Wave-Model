clc; close all; clear all;

%=========================================================================%
% 1) ADD DIRECTORIES TO THE SEARCH PATH.                                  %
%=========================================================================%

% Add the source directory to the search path
addpath('')

%=========================================================================%
% 2) DEFINE NONDIMENSIONAL PHYSICAL PARAMETERS, PARAMETERS FOR THE SPA-   %
%    TIAL AND TEMPORAL RESOLUTION AND OTHER COMPUTAIONAL PARAMETERS.      %
%=========================================================================%

% Define dimensionless parameters of the wave field
kph   = 2;       % Peak wave number times water depth (number or inf)
steep = 0.000001;     % Wave steepness (steep = 2*kp*<eta^2>^(1/2))
ND    = 2;         % Parameter for the directional distribution
gamma = 3.3;       % Peak enhancement factor

% Define the dimensionless size of the computational domain
lx = 50;                 % The domain size in the x-direction is lx peak wavelengths
ly = (1+ND)^(1/2)*lx;    % The domain size in the y-direction is ly peak wavelengths

% Define parameters related to the spatial resolution
Nx = 128;        % 2*Nx is the number of points used in the x-direction
Ny = 128;        % 2*Ny is the number of points used in the y-direction
Ns = 5;         % Ns+1 is the number of points used in the vertical dimension

% Define parameters related to the time integration
NPeriod = 10;     % The number of peak periods for which the wave field is integrated in time
NStep   = 50;    % The number of time steps per peak period
tAdjust = 10;    % The number of peak periods where the solutions is adjusted
nAdjust = 4;     % The exponent used in the adjustment scheme

% Define other computational parameters
bCoef    = 1.5;      % b is computed as bCoef*Hs
epsGMRES = 1E-9;     % The relative tolerance to which the linear system for the potential is solved

%=========================================================================%
% 3) DEFINE PHYSICAL PARAMETERS IN SI UNITS AND DEFINE GLOBAL VARIABLES.  %
%=========================================================================%

% Define fundamental physical scales in SI units
g       = 9.81;                % Gravitational acceleration
lambdap = 275;                 % Peak wavelength

% Calculate relevant physical scales of the wave field in SI units
kp     = 2*pi/lambdap;           % Peak wave number
h      = kph/kp;                 % Water depth
omegap = sqrt(g*kp*tanh(kph));   % Peak frequency
Tp     = 2*pi/omegap;            % Peak period
Hs     = steep*lambdap/pi;       % Significant wave height

% Calculate relevant physical scales of the computational domain
Lx = lx*lambdap;
Ly = ly*lambdap;
b  = bCoef*Hs;

% Calculate the time step
deltat = Tp/NStep;

% Define global variables used for time integration. NOTE: These variables
% are only manipulated in mainProgram.m and compws.m!
global maxIter        % The maximum number of GMRES iterations allowed 
global iterCoef       % The maximum number of iterations at is computed as maxIter(n+1) = iterCoef*iter(n)
global Fold           % Fold contains the three most recent solutions to the Laplace problem

%=========================================================================%
% 4) INITIALIZE THE SURFACE QUANTITIES eta AND Phis.                      %
%=========================================================================%

% Initialize y
y = initializeEtaPhis(Nx, Ny, ND, gamma, steep, kph, kp, omegap, h, g, Lx, Ly);

%=========================================================================%
% 5) CONSTRUCT TIME INDEPENDENT VECTORS AND MATRICES.                     %
%=========================================================================%

disp('Construct time independent matrices...')

% Construct derivative vectors for the x direction
Dx1 = 1i*2*pi/Lx*[transpose(0:Nx-1); 0; transpose(-Nx+1:-1)];
Dx2 = -(2*pi/Lx*[transpose(0:Nx); transpose(-Nx+1:-1)]).^2;

% Construct derivative vectors for the y direction
Dy1 = 1i*2*pi/Ly*[0:Ny-1, 0, -Ny+1:-1];
Dy2 = -(2*pi/Ly*[0:Ny, -Ny+1:-1]).^2;

% Construct the differentiation matrices for the vertical direction
sGrid  = JacobiGL(0 ,0, Ns);
s1Vec  = transpose(1 + sGrid);
s1Vec2 = s1Vec.^2; 
[Ds1, Ds2] = ConstructLegendreDerivMat(Ns, sGrid);

% Construct KMat, TMat, DMat and the LU decomposition of the preconditioner
[KMat, TMat, DMat]          = constructKMatTMatDMat(Nx, Ny, Lx, Ly, kp, h, b);
[decompL, decompU, decompP] = compLUPrecon(Nx, Ny, Ns, Ds1, Ds2, KMat, transpose(TMat), b);

%=========================================================================%
% 6) INTEGRATE THE WAVE IN TIME FOR NPeriod PERIODS.                      %
%=========================================================================%

disp('Perform time integration...')

% Allocate arrays for data analsysis
etaMoments   = zeros(NStep, 4);

% Initialize global variables
maxIter  = 5;
iterCoef = 1.2;
Fold     = zeros(2*Nx*2*Ny*(Ns+1), 3);

% Perform the time integration
t   = 0;
nts = 1;
for nt = 1:NPeriod*NStep+1
    % Print out the time in units of peak periods and reset the time series
    % index if needed
    t
    if mod(nts-1,NStep) == 0
        nts = 1;
    end
    
    % Write the surface quantities and the moments of the surface elevatin 
    % of the past period to file in the folder "OutputData" every peak 
    % period
    if nts == 1
        dlmwrite(['OutputData/ySteep', num2str(1000000*steep), 'kph', num2str(10*kph), 'ND', num2str(ND), ...
                  'Time', num2str((nt-1)/NStep), 'Nx', num2str(Nx), 'Ny', num2str(Ny), ...
                   'Ns', num2str(Ns), 'NStep', num2str(NStep)], y);
        if t > 0
            dlmwrite(['OutputData/etaMomentsSteep', num2str(1000000*steep), 'kph', num2str(10*kph), ...
                      'ND', num2str(ND), 'Time', num2str((nt-1)/NStep), 'Nx', num2str(Nx), 'Ny', num2str(Ny), ...
                      'Ns', num2str(Ns), 'NStep', num2str(NStep)], etaMoments)
        end
    end
    
    % Advance y one time step
    tic
    y = rk4Step(y, t, deltat, deltat/Tp, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, s1Vec, s1Vec2, b, g,...
                epsGMRES, decompL, decompU, decompP, DMat, KMat, tAdjust, nAdjust);
    toc
        
    % Update the moments of the surface elevation at the ntsth time step 
    % whithin the current peak period
    eta2 = y(1:2*Nx*2*Ny).^2;
    eta3 = eta2.*y(1:2*Nx*2*Ny);
    eta4 = eta3.*y(1:2*Nx*2*Ny);
    etaMoments(nts,1) = sum(y(1:2*Nx*2*Ny))/(2*Nx*2*Ny);
    etaMoments(nts,2) = sum(eta2)/(2*Nx*2*Ny);
    etaMoments(nts,3) = sum(eta3)/(2*Nx*2*Ny);
    etaMoments(nts,4) = sum(eta4)/(2*Nx*2*Ny);
    
    % Update the time in units of TP and update nts
    t   = nt/NStep;
    nts = nts + 1;
end
  