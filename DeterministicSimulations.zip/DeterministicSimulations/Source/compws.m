%=========================================================================%
% This function computes the vertical fluid velocity at the surface (ws). %
%=========================================================================%

function ws = compws(y, etax, etay, etaGrad2, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, s1Vec, s1Vec2, b, ...
                     epsGMRES, decompL, decompU, decompP, Fguess)

% Load global variables
global maxIter;
global iterCoef;
global Fold;

% Compute b+eta, (b+eta)^2, and etaxx+etayy
beta  = b + y(1:2*Nx*2*Ny);
beta2 = beta.^2;
etaLaplace = reshape(ifft(Dx2.*fft(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]))), [2*Nx*2*Ny, 1]) ...
             + reshape(ifft(fft(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]), 2*Ny, 2).*Dy2, 2*Ny, 2), [2*Nx*2*Ny, 1]);         
         
% Compute (b+eta)*etax, (b+eta)*detady and beta*(etaxx+etayy)
betaTimesEtax       = beta.*etax;
betaTimesEtay       = beta.*etay;
betaTimesEtaLaplace = beta.*etaLaplace;

% Construct the right hand side vector for the Laplace equation
rhsVec = zeros(2*Nx*2*Ny*(Ns+1), 1);
rhsVec(2*Nx*2*Ny*Ns+1:2*Nx*2*Ny*(Ns+1)) = y(2*Nx*2*Ny+1:2*2*Nx*2*Ny);
    

% Construct handles for the laplace operator and the preconditioner
laplaceOperatorHandle = @(F) applyLaplaceOperator(F, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, ...
                             beta, beta2, s1Vec, s1Vec2, etaGrad2, betaTimesEtax, betaTimesEtay, betaTimesEtaLaplace);
preconHandle = @(F) applyPrecon(F, Nx, Ny, Ns, decompL, decompU, decompP);


% Solve the Laplace equation and take the real part of F to make sure that
% F is real!
[F, flag, resrel, iter] = gmres(laplaceOperatorHandle, rhsVec, [], epsGMRES, maxIter, preconHandle, [], Fguess);
F = real(F);

% Update global variables
maxIter  = ceil(iterCoef*iter(2));
Fold     = [F, Fold(:,1:2)]; 

% Compute ws from F
ws = 2./beta.*(reshape(F, [2*Nx*2*Ny, Ns+1])*Ds1(:,Ns+1));

end  