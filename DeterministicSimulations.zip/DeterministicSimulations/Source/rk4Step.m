%=========================================================================%
% This function advances y one time step using the classical 4th ordr     %
% Runge Kutta method.                                                     %
%=========================================================================%

function ynew = rk4Step(yold, deltat, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, s1Vec, s1Vec2, b, g, ...
    epsGMRES, decompL, decompU, decompP, dampStrat, DMat)

% Load global variables
global Fold

% Compute k1, k2, k3 and k4
k1 = deltat*compdydt(yold, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, s1Vec, s1Vec2, b, g,...
                     epsGMRES, decompL, decompU, decompP, Fold(:,1));
k2 = deltat*compdydt(yold+k1/2, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, s1Vec, s1Vec2, b, g,...
                     epsGMRES, decompL, decompU, decompP, 2*Fold(:,1)-Fold(:,3));
k3 = deltat*compdydt(yold+k2/2, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, s1Vec, s1Vec2, b, g,...
                     epsGMRES, decompL, decompU, decompP, Fold(:,1));
k4 = deltat*compdydt(yold+k3, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, s1Vec, s1Vec2, b, g,...
                     epsGMRES, decompL, decompU, decompP, 2*Fold(:,1)-Fold(:,3));

% Compute ynew and apply damping if dampStrat = 2
ynew = yold + 1/6*(k1 + 2*k2 + 2*k3 + k4);

if dampStrat == 2
    ynew(1:2*Nx*2*Ny)             = reshape(ifft2(DMat.*fft2(reshape(ynew(1:2*Nx*2*Ny), [2*Nx, 2*Ny]))), [2*Nx*2*Ny, 1]);
    ynew(2*Nx*2*Ny+1:2*2*Nx*2*Ny) = reshape(ifft2(DMat.*fft2(reshape(ynew(2*Nx*2*Ny+1:2*2*Nx*2*Ny), [2*Nx, 2*Ny]))), [2*Nx*2*Ny, 1]);
end

end