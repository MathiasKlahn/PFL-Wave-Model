%=========================================================================%
% This function initializes the Fourier coefficients of eta and phis      %
% by calling the routine SSGW.                                            %
%=========================================================================%

function [y, T] = initializeCW(steep, Nx, Ny, NSSGW, wlX, wlY, lambda, h, g, kp, kq, epsDist)

% Calculate physical scales
Lx = wlX*lambda;        % Domain length in the x direction
Ly = wlY*lambda/kq;     % Domain length in the y direction
k  = 2*pi/lambda;       % Fundamental wave number
a  = lambda*steep/2;    % Amplitude of the disturbance

% Call SSGW to get eta and phis on the default grid which is NOT evenly
% spaced as well as the physical parameters PP
[zs, ws, PP, phis] = SSGW(2*pi/lambda*h, pi*steep, NSSGW);

x    = [h*real(zs(1:NSSGW)); h*real(zs(NSSGW+1:end))];
eta  = h*[imag(zs(1:NSSGW)); imag(zs(NSSGW+1:end))  ];
phis = h*sqrt(g*h)*[phis(1:NSSGW); phis(NSSGW+1:end)];

% Use MATLABs spline routine to get the values of eta and phis on an evenly
% spaced grid
xEven    = linspace(0, lambda*(2*NSSGW-1)/(2*NSSGW), 2*NSSGW);
etaEven  = interp1(x, eta, xEven, 'spline');
PhisEven = interp1(x, phis, xEven, 'spline');

% Compute the scaled DFT of eta and phis on the evenly spaced grid
DFTeta  = fft(etaEven)/length(etaEven);
DFTPhis = fft(PhisEven)/length(PhisEven);

% Extract the 2*N_basis+1 coefficients of eta and phis as well as the
% 2*N_exact+1 coefficients of ws
etaCoef = zeros(2*Nx/wlX, 1);
etaCoef(1:Nx/wlX)      = DFTeta(1:Nx/wlX);
etaCoef(Nx/wlX+1)      = 2*real(DFTeta(Nx/wlX+1));
etaCoef(Nx/wlX+2:2*Nx/wlX) = flipud(conj(etaCoef(2:Nx/wlX)));

PhisCoef = zeros(2*Nx/wlX, 1);
PhisCoef(1:Nx/wlX)      = DFTPhis(1:Nx/wlX);
PhisCoef(Nx/wlX+1)      = 2*real(DFTPhis(Nx/wlX+1));
PhisCoef(Nx/wlX+2:2*Nx/wlX) = flipud(conj(PhisCoef(2:Nx/wlX)));


% Fill in the vector ySingle
ySingle = zeros(2*2*Nx/wlX,1);
ySingle(1:2*Nx/wlX)            = 2*Nx/wlX*ifft(etaCoef);
ySingle(2*Nx/wlX+1:2*2*Nx/wlX) = 2*Nx/wlX*ifft(PhisCoef);

% Fill in the unperturbed wave field
etaVec = zeros(2*Nx, 1);
PhisVec = zeros(2*Nx, 1);
for nwl = 1:wlX
    etaVec((nwl-1)*2*Nx/wlX+1:nwl*2*Nx/wlX)  =  ySingle(1:2*Nx/wlX);
    PhisVec((nwl-1)*2*Nx/wlX+1:nwl*2*Nx/wlX) = -ySingle(2*Nx/wlX+1:2*2*Nx/wlX);
end
    
y = zeros(2*2*Nx*2*Ny,1);
for ny = 1:2*Ny
    y((ny-1)*2*Nx+1:ny*2*Nx) = etaVec;
    y((2*Ny+ny-1)*2*Nx+1:(2*Ny+ny)*2*Nx) = PhisVec;
end

% Add the disturbance to the wave field
for ny = 1:2*Ny
    yny = Ly*(ny-1)/(2*Ny);
    for nx = 1:2*Nx
        xnx = Lx*(nx-1)/(2*Nx);
        y((2*Ny+ny-1)*2*Nx+nx) = y((2*Ny+ny-1)*2*Nx+nx) + epsDist*a*sqrt(g)/((k*kp)^2 + (k*kq)^2)^(1/4)*cos(k*kp*xnx)*cos(k*kq*yny)*exp(((k*kp)^2 + (k*kq)^2)^(1/2)*y((ny-1)*2*Nx+nx));
        y((ny-1)*2*Nx+nx)      = y((ny-1)*2*Nx+nx) + epsDist*a*sin(k*kp*xnx)*cos(k*kq*yny);
    end
end

% Compute the wave period T from the physical parameters
T = lambda/(sqrt(g*h)*PP(4));

endnd
end