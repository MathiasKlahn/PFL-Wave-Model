function y = initializeFE(A, Nx, Ny, Lx, Ly, h, g, x0, y0, t0)

% Define case specific parameters in SI units
sTheta  = 4;          % Spreading parameter
fMin = 46/64;      % Smallest allowed frequency
fMax = 106/64;     % Largest allowed frequency

% Construct kxList and kyList containing the wave numbers in the x- and
% y-directions
kxList = 2*pi/Lx*[0:Nx, -Nx+1:-1];
kyList = 2*pi/Ly*[0:Ny, -Ny+1:-1];

% Construct kMat, omegaMat and thetaMat containing the magnitude of the
% wave vectors, the corresponding linear frequencies and the angles of the
% wave vectors with respect to the x axis
kMat     = zeros(2*Nx, 2*Ny);
omegaMat = zeros(2*Nx, 2*Ny);
thetaMat = zeros(2*Nx, 2*Ny);
for nx = 1:2*Nx
    for ny = 1:2*Ny
        k = sqrt(kxList(nx)^2 + kyList(ny)^2);
        kMat(nx,ny)     = k;
        omegaMat(nx,ny) = sqrt(g*k*tanh(k*h));
        if kxList(nx) > 0
            thetaMat(nx,ny) = atan(kyList(ny)/kxList(nx));
        elseif kxList(nx) == 0
            thetaMat(nx,ny) = pi/2;
        else
            thetaMat(nx,ny) = atan(kyList(ny)/kxList(nx)) + pi;
        end
    end
end

% Construct kSpec containing the wave number spectrum
kSpec = zeros(2*Nx, 2*Ny);
for nx = 1:2*Nx
    for ny = 1:2*Ny
        if kMat(nx,ny) > 0 && 2*pi*fMin < omegaMat(nx,ny) && omegaMat(nx,ny) < 2*pi*fMax
            kSpec(nx,ny) = (fMax*fMin/(fMax-fMin))*(omegaMat(nx,ny)/(2*pi))^(-2);
            kSpec(nx,ny) = kSpec(nx,ny)/(2*pi*kMat(nx,ny));
            kSpec(nx,ny) = kSpec(nx,ny)*0.5*(1+2*kMat(nx,ny)*h/sinh(2*kMat(nx,ny)*h))*omegaMat(nx,ny)/kMat(nx,ny);
        end
    end
end

% Construct thetaSpec containing the directional spectrum. Note that it is
% NOT normalized (beacuse this will be done later anyway!)
thetaSpec = zeros(2*Nx, 2*Ny);
for nx = 1:2*Nx
    for ny = 1:2*Ny
        if abs(thetaMat(nx,ny)) < pi/4
            thetaSpec(nx,ny) = cos(thetaMat(nx,ny)/2)^sTheta;
        end
    end
end

% Compute etaCoefMat containing the expansion coefficients of eta at the focus
% time
etaCoefMat = zeros(2*Nx, 2*Ny);
for nx = 1:Nx+1
    for ny = 1:2*Ny
        etaCoefMat(nx,ny) = kSpec(nx,ny)*thetaSpec(nx,ny);
    end
end
for nx = 1:Nx
    for ny = 1:Ny
        etaCoefMat(2*Nx+1-nx, 2*Ny+1-ny) = etaCoefMat(nx+1, ny+1);
    end
end
for nx = 1:Nx
    for ny = 1:Ny
        etaCoefMat(2*Nx+1-nx,ny+1) = etaCoefMat(nx+1, 2*Ny+1-ny);
    end
end
for nx = 1:Nx
    etaCoefMat(2*Nx+1-nx, 1) = etaCoefMat(nx+1,1);
end
for ny = 1:Ny
    etaCoefMat(1, 2*Ny+1-ny) = etaCoefMat(1,ny+1);
end

% Compute phisCoefMat containing the expansion coefficients of Phis
phisCoefMat = zeros(2*Nx, 2*Ny);
for nx = 1:2*Nx
    for ny = 1:2*Ny
        if kMat(nx,ny) > 0
            phisCoefMat(nx,ny) = omegaMat(nx,ny)/(kMat(nx,ny)*tanh(kMat(nx,ny)*h))*etaCoefMat(nx,ny);
        end
    end
end

% Scale the coefficients such that the largest value of eta is A
%scale = A/max(max(ifft2(etaCoefMat)));
scale = sum(sum(etaCoefMat));
etaCoefMat  = etaCoefMat/scale;
phisCoefMat = phisCoefMat/scale; 

% "Move" the coefficients such that the simulation starts at t0 and the
% focus appears at (x0,y0) according to linear theory
for nx = 1:Nx+1
    for ny = 1:2*Ny
        etaCoefMat(nx,ny)  = etaCoefMat(nx,ny)*exp(1i*omegaMat(nx,ny)*t0 + 1i*(kxList(nx)*x0 + kyList(ny)*y0));
        phisCoefMat(nx,ny) = 1i*phisCoefMat(nx,ny)*exp(1i*omegaMat(nx,ny)*t0 + 1i*(kxList(nx)*x0 + kyList(ny)*y0));
    end
end
for nx = Nx+2:2*Nx
    for ny = 1:2*Ny
        etaCoefMat(nx,ny)  = etaCoefMat(nx,ny)*exp(-1i*omegaMat(nx,ny)*t0 + 1i*(kxList(nx)*x0 + kyList(ny)*y0));
        phisCoefMat(nx,ny) = -1i*phisCoefMat(nx,ny)*exp(-1i*omegaMat(nx,ny)*t0 + 1i*(kxList(nx)*x0 + kyList(ny)*y0));
    end
end

% Compute the surface elevation and surface potential and fill them into
% the vector y
y = A*[reshape(real(fft2(etaCoefMat)), [2*Nx*2*Ny,1]); reshape(real(fft2(phisCoefMat)), [2*Nx*2*Ny,1])];

   
end                                 