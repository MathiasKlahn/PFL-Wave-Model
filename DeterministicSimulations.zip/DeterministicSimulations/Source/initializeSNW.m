%=========================================================================%
% This function initializes the Fourier coefficients of eta and phis      %
% by calling the routine SSGW.                                            %
%=========================================================================%

function [y, T] = initializeSNW(h, L, g, steep, Nx, Ny, NSSGW)

% Call SSGW to get eta and phis on the default grid which is NOT evenly
% spaced as well as the physical parameters PP
[zs, ws, PP, phis] = SSGW(2*pi/L*h, pi*steep, NSSGW);

x    = [h*real(zs(1:NSSGW)); h*real(zs(NSSGW+1:end))];
eta  = h*[imag(zs(1:NSSGW)); imag(zs(NSSGW+1:end))  ];
phis = h*sqrt(g*h)*[phis(1:NSSGW); phis(NSSGW+1:end)];

% Use MATLABs spline routine to get the values of eta and phis on an evenly
% spaced grid
xEven    = linspace(0, L*(2*NSSGW-1)/(2*NSSGW), 2*NSSGW);
etaEven  = interp1(x, eta, xEven, 'spline');
PhisEven = interp1(x, phis, xEven, 'spline');

% Compute the scaled DFT of eta and phis on the evenly spaced grid
DFTeta  = fft(etaEven)/length(etaEven);
DFTPhis = fft(PhisEven)/length(PhisEven);

% Extract the 2*N_basis+1 coefficients of eta and phis as well as the
% 2*N_exact+1 coefficients of ws
etaCoef = zeros(2*Nx, 1);
etaCoef(1:Nx)      = DFTeta(1:Nx);
etaCoef(Nx+1)      = 2*real(DFTeta(Nx+1));
etaCoef(Nx+2:2*Nx) = flipud(conj(etaCoef(2:Nx)));

PhisCoef = zeros(2*Nx, 1);
PhisCoef(1:Nx)      = DFTPhis(1:Nx);
PhisCoef(Nx+1)      = 2*real(DFTPhis(Nx+1));
PhisCoef(Nx+2:2*Nx) = flipud(conj(PhisCoef(2:Nx)));

% Fill in the vector y = [eta; phis]^T
y = zeros(2*2*Nx*2*Ny,1);
for ny = 1:2*Ny
    y((ny-1)*2*Nx+1:ny*2*Nx)             = 2*Nx*ifft(etaCoef);
    y((2*Ny+ny-1)*2*Nx+1:(2*Ny+ny)*2*Nx) = 2*Nx*ifft(PhisCoef);
end

% Change the phase of y0 such that the crest is located at x = Lx/2
indexList = transpose([0:Nx, -Nx+1:-1]);
for ny = 1:2*Ny
    y((ny-1)*2*Nx+1:ny*2*Nx) = ifft((-1).^indexList.*fft(y((ny-1)*2*Nx+1:ny*2*Nx)));
    y(2*Nx*2*Ny+(ny-1)*2*Nx+1:2*Nx*2*Ny+ny*2*Nx) = -1*ifft((-1).^indexList.*fft(y(2*Nx*2*Ny+(ny-1)*2*Nx+1:2*Nx*2*Ny+ny*2*Nx)));
end

% Compute the wave period T from the physical parameters
T = L/(sqrt(g*h)*PP(4));

end  