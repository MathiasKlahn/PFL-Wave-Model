%=========================================================================%
% This function initializes the Gaussian hump at rest.                    %
%=========================================================================%

function y = initializeGH(Nx, Ny, L, H, sigma)

%y = HTilde*ones(2*2*Nx*2*Ny, 1);
y = H*ones(2*2*Nx*2*Ny, 1);
for ny = 1:2*Ny
    yny = L*(ny-1)/(2*Ny);
    for nx = 1:2*Nx
        xnx = L*(nx-1)/(2*Nx);
        y((ny-1)*2*Nx+nx) = H*exp(-((xnx - L/2)^2 + (yny - L/2)^2)/(sigma)^2);
    end
end


end