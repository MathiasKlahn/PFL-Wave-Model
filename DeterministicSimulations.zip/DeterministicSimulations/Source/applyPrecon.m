%=========================================================================%
% This function applies the preconditioner to the vector F.               %
%=========================================================================%

function preconF = applyPrecon(F, Nx, Ny, Ns, decompL, decompU, decompP)

% Compute the Fourier represenation of F at each s point
preconF = reshape(fft2(reshape(F, [2*Nx, 2*Ny, Ns+1])), [2*Nx*2*Ny*(Ns+1),1]);

% Apply the precondition to the Fourier representation of F
preconF = decompU\(decompL\(decompP*preconF));

% Compute the point representation of preconF
preconF = reshape(ifft2(reshape(preconF, [2*Nx, 2*Ny, Ns+1])), [2*Nx*2*Ny*(Ns+1),1]);

end