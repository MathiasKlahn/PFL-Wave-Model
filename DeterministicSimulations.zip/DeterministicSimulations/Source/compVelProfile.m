%=========================================================================%
% This function computes the vertical profile of each of the components   %
% of the fluid velocity.                                                  %
%=========================================================================%

function [uProfile, vProfile, wProfile] = ...
                    compVelProfile(y, zGrid, sGrid, xPos, yPos, h, b, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2,KMat, TMat, ...
                                   s1Vec, s1Vec2, epsGMRES, decompL, decompU, decompP)

% Compute etax, etay and etaGrad2
etax = reshape(ifft(Dx1.*fft(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]))), [2*Nx*2*Ny, 1]);
etay = reshape(ifft(fft(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]), 2*Ny, 2).*Dy1, 2*Ny, 2), [2*Nx*2*Ny, 1]);
etaGrad2 = etax.^2 + etay.^2;
                             
% Compute b+eta, (b+eta)^2, and etaxx+etayy
beta  = b + y(1:2*Nx*2*Ny);
beta2 = beta.^2;
etaLaplace = reshape(ifft(Dx2.*fft(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]))), [2*Nx*2*Ny, 1]) ...
             + reshape(ifft(fft(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]), 2*Ny, 2).*Dy2, 2*Ny, 2), [2*Nx*2*Ny, 1]);         
                  
% Compute (b+eta)*etax, (b+eta)*detady and beta*(etaxx+etayy)
betaTimesEtax       = beta.*etax;
betaTimesEtay       = beta.*etay;
betaTimesEtaLaplace = beta.*etaLaplace;

% Construct the right hand side vector for the Laplace equation
rhsVec = zeros(2*Nx*2*Ny*(Ns+1), 1);
rhsVec(2*Nx*2*Ny*Ns+1:2*Nx*2*Ny*(Ns+1)) = y(2*Nx*2*Ny+1:2*2*Nx*2*Ny);
    
% Construct handles for the laplace operator and the preconditioner
laplaceOperatorHandle = @(F) applyLaplaceOperator(F, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, ...
                             beta, beta2, s1Vec, s1Vec2, etaGrad2, betaTimesEtax, betaTimesEtay, betaTimesEtaLaplace);
preconHandle = @(F) applyPrecon(F, Nx, Ny, Ns, decompL, decompU, decompP);

% Solve the Laplace equation and take the real part of F to make sure that
% F is real!
F = gmres(laplaceOperatorHandle, rhsVec, [], epsGMRES, 20, preconHandle);
F = real(F);

% Compute derivatives of F
Fx  = reshape(ifft(Dx1.*fft(reshape(F, [2*Nx, 2*Ny*(Ns+1)]))), [2*Nx*2*Ny*(Ns+1),1]);
Fy  = reshape(ifft(fft(reshape(F, [2*Nx, 2*Ny, Ns+1]), 2*Ny, 2).*Dy1, 2*Ny, 2), [2*Nx*2*Ny*(Ns+1),1]);
Fs  = reshape(reshape(F, [2*Nx*2*Ny, Ns+1])*Ds1, [2*Nx*2*Ny*(Ns+1),1]);

% Compute the velocities in the upper part of the domain
u  = reshape(Fx - reshape(((etax./beta).*reshape(Fs, [2*Nx*2*Ny, Ns+1])).*s1Vec, [2*Nx*2*Ny*(Ns+1),1]), [2*Nx, 2*Ny, Ns+1]);
v  = reshape(Fy - reshape(((etay./beta).*reshape(Fs, [2*Nx*2*Ny, Ns+1])).*s1Vec, [2*Nx*2*Ny*(Ns+1),1]), [2*Nx, 2*Ny, Ns+1]);
w  = reshape(((2./beta).*reshape(Fs, [2*Nx*2*Ny, Ns+1])), [2*Nx, 2*Ny, Ns+1]);


% Evaluate u, v and w at the vertical grid points at (xPos,yPos)
uList = zeros(Ns+1,1);
vList = zeros(Ns+1,1);
wList = zeros(Ns+1,1);
for ns = 1:Ns+1
    uList(ns) = real(sum(sum(1/(2*Nx*2*Ny)*fft2(reshape(u(:,:,ns), [2*Nx, 2*Ny])).*exp(Dx1*xPos + Dy1*yPos))));
    vList(ns) = real(sum(sum(1/(2*Nx*2*Ny)*fft2(reshape(v(:,:,ns), [2*Nx, 2*Ny])).*exp(Dx1*xPos + Dy1*yPos))));
    wList(ns) = real(sum(sum(1/(2*Nx*2*Ny)*fft2(reshape(w(:,:,ns), [2*Nx, 2*Ny])).*exp(Dx1*xPos + Dy1*yPos))));
end

% Calculate the value of the surface elevation at the (xPos,yPos)
etaVal = real(sum(sum(1/(2*Nx*2*Ny)*fft2(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny])).*exp(Dx1*xPos + Dy1*yPos))))

% Compute the barycentric weights
barWts = compBarWts(Ns,sGrid);

% Compute the profiles of u and w
coshMat = cosh(KMat*(h-b));
sinhMat = sinh(KMat*(h-b));
    
uProfile = zeros(length(zGrid),1);
vProfile = zeros(length(zGrid),1);
wProfile = zeros(length(zGrid),1);

uCoef = 1/(2*Nx*2*Ny)*fft2(reshape(u(:,:,1), [2*Nx, 2*Ny]));
vCoef = 1/(2*Nx*2*Ny)*fft2(reshape(v(:,:,1), [2*Nx, 2*Ny]));
wCoef = 1/(2*Nx*2*Ny)*fft2(reshape(w(:,:,1), [2*Nx, 2*Ny]));
for n = 1:length(zGrid)
    % Check if the z grid point lies above or below the artificial boundary
    % condition
    if zGrid(n) < -b
        uProfile(n) = real(sum(sum((uCoef.*cosh(KMat*(h+zGrid(n)))./coshMat).*exp(Dx1*xPos + Dy1*yPos))));
        vProfile(n) = real(sum(sum((vCoef.*cosh(KMat*(h+zGrid(n)))./coshMat).*exp(Dx1*xPos + Dy1*yPos))));
    
        wCoefMod      = wCoef.*sinh(KMat*(h+zGrid(n)))./sinhMat;
        wCoefMod(1,1) = 0;
        wProfile(n)   = real(sum(sum(wCoefMod.*exp(Dx1*xPos + Dy1*yPos))));
    else
        % Check if the z grid point is very close to one of the quadrature
        % points
        indicator = 0;
        sVal = (2*zGrid(n)+b-etaVal)/(b+etaVal);
        for p = 1:Ns+1
            if abs(sVal - sGrid(p)) < 1E-6
                indicator = 1;
                break;
            end
        end
        % Evaluate the velocity from the known solution if indicator = 1 or
        % by interpolation if indicator = 0
        if indicator == 1
            uProfile(n) = uList(p);
            vProfile(n) = vList(p);
            wProfile(n) = wList(p);
        elseif indicator == 0
            uProfile(n) = evalInterp(uList, sVal, sGrid, barWts, Ns);
            vProfile(n) = evalInterp(vList, sVal, sGrid, barWts, Ns);
            wProfile(n) = evalInterp(wList, sVal, sGrid, barWts, Ns);
        end
    end
end

end  


%=========================================================================%
% This function Evaluates the Lagrangian interpolant.                     %
%=========================================================================%

function interp = evalInterp(fList, sVal, sGrid, barWts, Ns)

numerator = 0;
for ns = 1:Ns+1
    numerator = numerator + fList(ns)*barWts(ns)/(sVal - sGrid(ns));
end

denominator = 0;
for ns = 1:Ns+1
    denominator = denominator + barWts(ns)/(sVal - sGrid(ns));
end

interp = numerator/denominator;

end

%=========================================================================%
% This function computes the barycentric weights.                         %
%=========================================================================%

function barWts = compBarWts(Ns,sGrid)

barWts = ones(Ns+1,1);
for ns = 1:Ns+1
    for p = 1:ns-1
        barWts(ns) = barWts(ns)/(sGrid(ns) - sGrid(p));
    end
    for p = ns+1:Ns+1
        barWts(ns) = barWts(ns)/(sGrid(ns) - sGrid(p));
    end
end

end