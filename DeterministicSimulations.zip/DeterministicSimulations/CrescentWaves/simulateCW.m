clc; close all; clear all;

%=========================================================================%
% 1) ADD DIRECTORIES TO THE SEARCH PATH.                                  %
%=========================================================================%

% Add the source directory to the search path 
addpath('')

%=========================================================================%
% 2) DEFINE NONDIMENSIONAL PHYSICAL PARAMETERS, PARAMETERS FOR THE SPA-   %
%    TIAL AND TEMPORAL RESOLUTION AND OTHER COMPUTAIONAL PARAMETERS.      %
%=========================================================================%

% Define dimensionless parameters of the undistrubed wave
kh      = 2*pi;   % Fundamental wave number times water depth
steep   = 0.105;  % Wave steepness H/lambda
wlX     = 4;      % Number of wavelengths simulated in the x direction
wlY     = 2;      % Number of wavelengths simulated in the y direction
NPeriod = 50;      % The number of periods for which the wave is propagated in time

% Define dimensionless parameters of the disturbance
epsDist = 0.0001;   % The scaling of the amplitude of the disturbance 
kp      = 3/2;      % Wave number in the x direction of the disturbance in units of k
kq      = 1.23;     % Wave number in the y direction of the disturbance in units of k

% Define parameters related to the spatial resolution
Nx = 64;            % 2*Nx is the number of points used in the x direction
Ny = 16;            % 2*Ny is the number of points used in the y direction
Ns = 8;             % Ns+1 is the number of points used in the s direction

% Define parameters related to the temporal resolution
NStep     = 50;       % Number of time steps every period of the unperturbed wave

% Define parameters related to the damping strategy
dampStrat = 2;        % The damping stratety. If dampStrat = 1: No damping. If dampStrat = 2: Damp ynew in rk4Step
dampCoef  = 0.5;      % The damping coefficient. A Fourier coefficient of ynew is set to 0 if |k|/|kMax| <= dampCoef

% Define various computational parameters
NSSGW    = 10000;    % 2*NSSGW is the number of points used to initialize the unperturbed wave
epsGMRES = 1E-9;    % The relative tolerance to which the linear system of equations is solved
bParam   = 0.1;     % b is computed as b = (1+bParam)*max(eta)

%=========================================================================%
% 3) DEFINE PHYSICAL PARAMETERS IN SI UNITS AND DEFINE GLOBAL VARIABLES.  %
%=========================================================================%

% Define fundamental physical scales
lambda = 2*pi;    % Wavelength
g      = 9.81;    % Gravitational acceleration

% Calculate all other physical scales
Lx = wlX*lambda;        % Domain length in the x direction
Ly = wlY*lambda/kq;     % Domain length in the y direction
k  = 2*pi/lambda;       % Fundamental wave number
h  = kh/k;              % Water depth
a  = lambda*steep/2;    % Amplitude of the disturbance

% Define global variables used for time integration. NOTE: These variables
% are only manipulated in mainProgram.m and compws.m!
global maxIter        % The maximum number of GMRES iterations allowed 
global iterCoef       % The maximum number of iterations at is computed as maxIter(n+1) = iterCoef*iter(n)
global Fold           % Fold contains the three most recent solutions to the Laplace problem

%=========================================================================%
% 4) INITIALIZE y AND COMPUTE b AND THE TIME STEP.                        %
%=========================================================================%

% Initialize a single wavelength in (1D) of the unperturbed wave and 
% compute b and the time step
[y, T] = initializeCW(steep, Nx, Ny, NSSGW, wlX, wlY, lambda, h, g, kp, kq, epsDist);
b      = (1+bParam)*max(y(1:2*Nx/wlX));
deltat = T/NStep; 

%=========================================================================%
% 5) CONSTRUCT TIME INDEPENDENT MATRICES AND VECTORS FOR DIFFERENTIATION  %
%    AND PRECONDITIONING.                                                 %
%=========================================================================%

% Construct derivative vectors for the x direction
Dx1 = 1i*2*pi/Lx*[transpose(0:Nx-1); 0; transpose(-Nx+1:-1)];
Dx2 = -(2*pi/Lx*[transpose(0:Nx); transpose(-Nx+1:-1)]).^2;

% Construct derivative vectors for the y direction
Dy1 = 1i*2*pi/Ly*[0:Ny-1, 0, -Ny+1:-1];
Dy2 = -(2*pi/Ly*[0:Ny, -Ny+1:-1]).^2;

 % Construct the differentiation matrices for the vertical direction
sGrid      = JacobiGL(0 ,0, Ns);
s1Vec      = transpose(1 + sGrid);
s1Vec2     = s1Vec.^2; 
[Ds1, Ds2] = compLegendreDerivMat(Ns, sGrid);
    
% Construct KMat, TMat, DMat and the LU decomposition of the preconditioner
[KMat, TMat, DMat] = compKMatTMatDMat(Nx, Ny, Lx, Ly, h, b, dampCoef);
[decompL, decompU, decompP] = compLUPrecon(Nx, Ny, Ns, Ds1, Ds2, KMat, transpose(TMat), b);
    
%=========================================================================%
% 6) CARRY OUT THE TIME INTEGRATION.                                      %
%=========================================================================%

% Initialize global variables
maxIter  = 40;
iterCoef = 1.1;
Fold     = zeros(2*Nx*2*Ny*(Ns+1), 3);

% Perform the time integration
centerElevation = zeros(2*Nx, NStep*NPeriod);
coefTimeSeries  = zeros(NStep*NPeriod, 1);
alterSign = (-1).^([0:Ny, -Ny+1:-1]);
etaMax    = max(y(1:2*Nx*2*Ny));
tic
for nt = 1:NStep*NPeriod
    % Print out the time in units of periods
    t = nt/NStep
    
    % Advance y one time step
    y = rk4Step(y, deltat, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, s1Vec, s1Vec2, b, g,...
        epsGMRES, decompL, decompU, decompP, dampStrat, DMat);
    
    % Record the surface elevation at y = Ly/2 (the center elevation) and
    % the magnitude of the unstable Fourier coefficient
    eta     = reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]);
    etaCoef = 1/(2*Nx*2*Ny)*fft2(eta); 
    centerElevation(:,nt) = sum(1/(2*Ny)*fft(eta, 2*Ny, 2).*alterSign,2);
    coefTimeSeries(nt)    = etaCoef(7,3);
    
    % Animate the surface elevation
    figure(1)
    surf(1:2*Ny, 1:2*Nx, reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]))
    axis([0 2*Ny 0 2*Nx -2*etaMax 2*etaMax])
    view(-150,20)
end
toc

% Write the result of the compuation to file
dlmwrite(['OutputData/centerElevationNPeriod', num2str(NPeriod), 'NStep', num2str(NStep), ...
          'Nx', num2str(Nx), 'Ny', num2str(Ny), 'Ns', num2str(Ns), 'epsDist', num2str(1E4*epsDist)], ...
          centerElevation, 'precision','%.15f')
dlmwrite(['OutputData/coefTimeSeriesNPeriod', num2str(NPeriod), 'NStep', num2str(NStep), ...
          'Nx', num2str(Nx), 'Ny', num2str(Ny), 'Ns', num2str(Ns), 'epsDist', num2str(1E4*epsDist)], ...
          coefTimeSeries, 'precision','%.15f')      
dlmwrite(['OutputData/period'], T, 'precision','%.15f')

