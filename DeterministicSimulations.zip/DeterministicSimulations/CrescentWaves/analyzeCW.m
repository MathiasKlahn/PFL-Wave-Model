clc; close all; clear all;

%=========================================================================%
% 1) ADD DIRECTORIES TO THE SEARCH PATH.                                  %
%=========================================================================%

% Add the source directory to the search path 
addpath('')

%=========================================================================%
% 2) DEFINE NONDIMENSIONAL PHYSICAL PARAMETERS, PARAMETERS FOR THE SPA-   %
%    TIAL AND TEMPORAL RESOLUTION AND OTHER COMPUTAIONAL PARAMETERS.      %
%=========================================================================%

% Define dimensionless parameters of the undistrubed wave
kh      = 2*pi;   % Fundamental wave number times water depth
steep   = 0.105;  % Wave steepness H/lambda
wlX     = 4;      % Number of wavelengths simulated in the x direction
wlY     = 2;      % Number of wavelengths simulated in the y direction
NPeriod = 50;      % The number of periods for which the wave is propagated in time

% Define dimensionless parameters of the disturbance
epsDist = 0.0001;   % The scaling of the amplitude of the disturbance 
kp      = 3/2;      % Wave number in the x direction of the disturbance in units of k
kq      = 1.23;     % Wave number in the y direction of the disturbance in units of k

% Define parameters related to the spatial resolution
Nx = 64;            % 2*Nx is the number of points used in the x direction
Ny = 16;            % 2*Ny is the number of points used in the y direction
Ns = 8;             % Ns+1 is the number of points used in the s direction

% Define parameters related to the temporal resolution
NStep     = 50;       % Number of time steps every period of the unperturbed wave

%=========================================================================%
% 3) DEFINE PHYSICAL PARAMETERS IN SI UNITS AND DEFINE GLOBAL VARIABLES.  %
%=========================================================================%

% Define fundamental physical scales
lambda = 2*pi;    % Wavelength
g      = 9.81;    % Gravitational acceleration

% Calculate all other physical scales
Lx = wlX*lambda;        % Domain length in the x direction
Ly = wlY*lambda/kq;     % Domain length in the y direction
k  = 2*pi/lambda;       % Fundamental wave number
h  = kh/k;              % Water depth
a  = lambda*steep/2;    % Amplitude of the disturbance

%=========================================================================%
% 4) LOAD RESULTS FROM FILE.                                              %
%=========================================================================%

% Load the surface elevation at the center line
centerElevation = dlmread(['OutputData/centerElevationNPeriod', num2str(NPeriod), 'NStep', num2str(NStep), ...
                           'Nx', num2str(Nx), 'Ny', num2str(Ny), 'Ns', num2str(Ns), 'epsDist', num2str(1E4*epsDist)]);

% Load the time evolution of the unstable Fourier coefficient
coefTimeSeries = dlmread(['OutputData/coefTimeSeriesNPeriod', num2str(NPeriod), 'NStep', num2str(NStep), ...
                           'Nx', num2str(Nx), 'Ny', num2str(Ny), 'Ns', num2str(Ns), 'epsDist', num2str(1E4*epsDist)]);      

% Load the period of the unperturbed wave
T = dlmread('OutputData/Period');      
                       
%=========================================================================%
% 5) COMPUTE THE HEIGHT PARAMETERS OF THE CRESCENT PATTERN AS A FUNCTION  %
%    OF TIME.                                                             %
%=========================================================================%

% Compute the height ratios as a function of time
h11h12Ratio  = zeros(NPeriod*NStep,1);
h11h21Ratio  = zeros(NPeriod*NStep,1);
h21h22Ratio  = zeros(NPeriod*NStep,1);

for nt = 1:NPeriod*NStep
    % Extract the surface elevation
    eta = centerElevation(:,nt);
        
    % Find the local minima and maxima of eta
    throughIndex = [];
    throughVal   = [];
    crestIndex   = [];
    crestVal     = [];
    for nx = 1:2*Nx
        indexMiddle = nx;
        indexLeft   = nx-1;
        indexRight  = nx+1;
        if nx == 1
            indexLeft = 2*Nx;
        elseif nx == 2*Nx
            indexRight = 1;
        end
        
        if eta(indexLeft) > eta(indexMiddle) && eta(indexMiddle) < eta(indexRight)
            throughIndex = [throughIndex, indexMiddle];
            throughVal   = [throughVal, eta(indexMiddle)];
        elseif eta(indexLeft) < eta(indexMiddle) && eta(indexMiddle) > eta(indexRight)
            crestIndex = [crestIndex, indexMiddle];
            crestVal   = [crestVal, eta(indexMiddle)];
        end
    end
        
    % Compute the height ratios
    h11 = max(crestVal) - min(throughVal);
    h12 = max(crestVal) - max(throughVal);
    h21 = min(crestVal) - max(throughVal);
    h22 = min(crestVal) - min(throughVal);
    
    h11h12Ratio(nt) = h11/h12;
    h11h21Ratio(nt) = h11/h21;
    h21h22Ratio(nt) = h21/h22;
end

% Plot the ratio h11/h12
figure(1)
plot((1:2:NStep*NPeriod)/NStep, h11h12Ratio(1:2:NStep*NPeriod), 'LineWidth', 2)

set(gca, 'FontSize', 16)
set(gca, 'TickLabelInterpreter', 'latex')
set(gca, 'position', [0.16, 0.16, 0.80, 0.80])

xlabel('$t/T$', 'Interpreter', 'latex', 'FontSize', 22)
ylabel('$h_{11}/h_{12}$', 'Interpreter', 'latex', 'FontSize', 22)

axis([0 50 0.95 1.40])
xticks(0:10:50)

% Plot the ratio h11/h21
figure(2)
plot((1:2:NStep*NPeriod)/NStep, h11h21Ratio(1:2:NStep*NPeriod), 'LineWidth', 2)

set(gca, 'FontSize', 16)
set(gca, 'TickLabelInterpreter', 'latex')
set(gca, 'position', [0.16, 0.16, 0.80, 0.80])

xlabel('$t/T$', 'Interpreter', 'latex', 'FontSize', 22)
ylabel('$h_{11}/h_{21}$', 'Interpreter', 'latex', 'FontSize', 22)

axis([0 50 0.95 1.85])
xticks(0:10:50)

% Plot the ratio h21/h22
figure(3)
plot((1:2:NStep*NPeriod)/NStep, h21h22Ratio(1:2:NStep*NPeriod), 'LineWidth', 2)

set(gca, 'FontSize', 16)
set(gca, 'TickLabelInterpreter', 'latex')
set(gca, 'position', [0.16, 0.16, 0.80, 0.80])

xlabel('$t/T$', 'Interpreter', 'latex', 'FontSize', 22)
ylabel('$h_{21}/h_{22}$', 'Interpreter', 'latex', 'FontSize', 22)

axis([0 50 0.65 1.05])
xticks(0:10:50)

%=========================================================================%
% 6) COMPARE THE GROWTH RATE OF THE UNSTABLE FOURIER COEFFICIENT TO THE   %
%    RATE PREDICTED BY McLean.                                            %
%=========================================================================%

% Define the growth rate from McLean's analysis. NOTE: This growth rate
% only works for deep water (kh > 2*pi, say), steep = 0.105, kp = 3/2 and
% kq = 1.23. For other values of these parameters the comparison will not
% make sense!
mcLeanGR = 0.0316;

% Make the comparison between the simulate result and that of McLean
figure(4)
semilogy((0:NStep*NPeriod-1)/NStep, abs(coefTimeSeries(1:NStep*NPeriod)/coefTimeSeries(1)), 'LineWidth', 2)
hold on
semilogy((0:NStep*NPeriod-1)/NStep, exp(0.0316*sqrt(g*k)*T*(0:NStep*NPeriod-1)/NStep), 'k--', 'LineWidth', 2)

axis([0 NPeriod 0.7 1E4])

set(gca, 'FontSize', 16)
set(gca, 'TickLabelInterpreter', 'latex')
set(gca, 'position', [0.16, 0.16, 0.80, 0.80])

xlabel('$t/T$', 'Interpreter', 'latex', 'FontSize', 22)
ylabel('$|\widehat{\eta}_{6,2}|$ (arbitrary units)', 'Interpreter', 'latex', 'FontSize', 22)
