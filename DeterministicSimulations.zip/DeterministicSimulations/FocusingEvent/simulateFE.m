clc; close all; clear all;

%=========================================================================%
% 1) ADD DIRECTORIES TO THE SEARCH PATH.                                  %
%=========================================================================%

% Add the source directory to the search path
addpath('')

%=========================================================================%
% 2) DEFINE PHYSICAL PARAMETERS, PARAMETERS FOR THE SPATIAL AND TEMPORAL  %
%    AND OTHER COMPUTAIONAL PARAMETERS.                                   %
%=========================================================================%

% Define length parameters in SI units
Lx = 25.6;          % Domain length in the x direction
Ly = 25.6;          % Domain length in the x direction
g  = 9.81;          % Gravitational acceleration
h  = 1.2;           % Water depth
A  = 78E-3;         % The maximum surface elevation according to linear theory
x0 = 20;            % The x-coordinate of the focus position
y0 = Ly/2;          % The y-coordinate of the focus position
b  = 0.12;          % The vertical position of the artificial boundary condition

% Define time parameters in SI units
t0 = -20;
tf =  10;
deltat = 0.01;

% Define parameters related to the spatial resolution
Nx = 128;        % The number of points in the x direction is 2*Nx
Ny = 128;        % The number of points in the y direction is 2*Ny
Ns = 10;        % Ns+1 is the number of points used in the vertical dimension

% Define parameters related to the damping strategy
dampStrat = 2;        % The damping stratety. If dampStrat = 1: No damping. If dampStrat = 2: Damp ynew in rk4Step
dampCoef  = 0.7;      % The damping coefficient. A Fourier coefficient of ynew is set to 0 if |k|/|kMax| <= dampCoef

% Define other computational parameters
epsGMRES  = 1E-9;    % The relative tolerance to which the linear system for the potential is solved

% Define global variables used for time integration. NOTE: These variables
% are only manipulated in mainProgram.m and compws.m!
global maxIter        % The maximum number of GMRES iterations allowed 
global iterCoef       % The maximum number of iterations at is computed as maxIter(n+1) = iterCoef*iter(n)
global Fold           % Fold contains the three most recent solutions to the Laplace problem

%=========================================================================%
% 3) INITIALIZE y.                                                        %
%=========================================================================%

% Initialize y
y = initializeFE(A, Nx, Ny, Lx, Ly, h, g, x0, y0, t0);


%=========================================================================%
% 4) CONSTRUCT TIME INDEPENDENT MATRICES AND VECTORS FOR DIFFERENTIATION  %
%    AND PRECONDITIONING.                                                 %
%=========================================================================%

% Construct derivative vectors for the x direction
Dx1 = 1i*2*pi/Lx*[transpose(0:Nx-1); 0; transpose(-Nx+1:-1)];
Dx2 = -(2*pi/Lx*[transpose(0:Nx); transpose(-Nx+1:-1)]).^2;

% Construct derivative vectors for the y direction
Dy1 = 1i*2*pi/Ly*[0:Ny-1, 0, -Ny+1:-1];
Dy2 = -(2*pi/Ly*[0:Ny, -Ny+1:-1]).^2;

% Construct the differentiation matrices for the vertical direction
sGrid  = JacobiGL(0 ,0, Ns);
s1Vec  = transpose(1 + sGrid);
s1Vec2 = s1Vec.^2; 
[Ds1, Ds2] = compLegendreDerivMat(Ns, sGrid);

% Construct KMat, TMat, DMat and the LU decomposition of the preconditioner
[KMat, TMat, DMat] = compKMatTMatDMat(Nx, Ny, Lx, Ly, h, b, dampCoef);
[decompL, decompU, decompP] = compLUPrecon(Nx, Ny, Ns, Ds1, Ds2, KMat, transpose(TMat), b);

%=========================================================================%
% 5) CARRY OUT THE TIME INTEGRATION.                                      %
%=========================================================================%

disp('Perform time integration...')

% Initialize global variables
maxIter  = 5;
iterCoef = 1.2;
Fold     = zeros(2*Nx*2*Ny*(Ns+1), 3);


% Allocate arrays for the surface elevation at the focus point and the time
focusElevation = zeros((tf-t0)/deltat,1);
time           = zeros((tf-t0)/deltat,1);

% Perform the time integration
t = t0;
for nt = 1:(tf-t0)/deltat
    % Calculate the surface elevation at the focus point and record the
    % time
    focusElevation(nt) = real(sum(sum(1/(2*Nx*2*Ny)*fft2(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny])).*exp(Dx1*x0 + Dy1*y0))));
    time(nt)           = t;
    
    % Advance y one time step
    y = rk4Step(y, deltat, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, s1Vec, s1Vec2, b, g,...
        epsGMRES, decompL, decompU, decompP, dampStrat, DMat);
    
    % Advance the time one time step
    t = t + deltat
    
    % Animate the surface elevation
    figure(1)
    %contourf(log(abs(fft2(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny])))))
    contourf(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]), 'EdgeColor', 'none')
    %surf(1:2*Ny, 1:2*Nx, reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]), 'EdgeColor', 'none')
    %axis([0 2*Ny 0 2*Nx -b b])
end

% Write the result of the computation to file
dlmwrite(['OutputData/focusElevationt0', num2str(abs(t0)), 'tf', num2str(abs(tf)), ...
          'Nx', num2str(Nx), 'Ny', num2str(Ny), 'Ns', num2str(Ns)], focusElevation, 'precision','%.15f')
dlmwrite(['OutputData/timet0', num2str(abs(t0)), 'tf', num2str(abs(tf)), ...
          'Nx', num2str(Nx), 'Ny', num2str(Ny), 'Ns', num2str(Ns)], time, 'precision','%.15f')

