clc; close all; clear all;

%=========================================================================%
% 1) ADD DIRECTORIES TO THE SEARCH PATH.                                  %
%=========================================================================%

% Add the source directory to the search path
addpath('')

%=========================================================================%
% 2) DEFINE PHYSICAL PARAMETERS, PARAMETERS FOR THE SPATIAL AND TEMPORAL  %
%    AND OTHER COMPUTAIONAL PARAMETERS.                                   %
%=========================================================================%

% Define length parameters in SI units
Lx = 25.6;          % Domain length in the x direction
Ly = 25.6;          % Domain length in the x direction
g  = 9.81;          % Gravitational acceleration
h  = 1.2;           % Water depth
A  = 78E-3;         % The maximum surface elevation according to linear theory
x0 = 20;            % The x-coordinate of the focus position
y0 = Ly/2;          % The y-coordinate of the focus position

% Define time parameters in SI units
t0 = -20;
tf =  10;
deltat = 0.01;

% Define parameters related to the spatial resolution
Nx = 128;        % The number of points in the x direction is 2*Nx
Ny = 128;        % The number of points in the y direction is 2*Ny
Ns = 10;         % Ns+1 is the number of points used in the vertical dimension

% Define parameters related to the damping strategy
dampStrat = 2;        % The damping stratety. If dampStrat = 1: No damping. If dampStrat = 2: Damp ynew in rk4Step
dampCoef  = 0.7;      % The damping coefficient. A Fourier coefficient of ynew is set to 0 if |k|/|kMax| <= dampCoef

% Define other computational parameters
epsGMRES  = 1E-9;    % The relative tolerance to which the linear system for the potential is solved

%=========================================================================%
% 3) LOAD RESULTS FROM FILE AND PLOT THEM.                                %
%=========================================================================%

% Load results
focusElevation = dlmread(['OutputData/focusElevationt0', num2str(abs(t0)), 'tf', num2str(abs(tf)), ...
          'Nx', num2str(Nx), 'Ny', num2str(Ny), 'Ns', num2str(Ns)]);
time = dlmread(['OutputData/timet0', num2str(abs(t0)), 'tf', num2str(abs(tf)), ...
          'Nx', num2str(Nx), 'Ny', num2str(Ny), 'Ns', num2str(Ns)]);

% Plot the results
figure(1)
plot(time, focusElevation, 'LineWidth', 2)

set(gca, 'FontSize', 16)
set(gca, 'TickLabelInterpreter', 'latex')
set(gca, 'position', [0.18, 0.18, 0.78, 0.78])

xlabel('$t$ (s)', 'Interpreter', 'latex', 'FontSize', 22)
ylabel('$\eta(x_0, y_0, t)$ (m)', 'Interpreter', 'latex', 'FontSize', 22)
      
