clc; close all; clear all;

%=========================================================================%
% 1) ADD DIRECTORIES TO THE SEARCH PATH.                                  %
%=========================================================================%

% Add the source directory to the search path
addpath('')

%=========================================================================%
% 2) DEFINE NONDIMENSIONAL PHYSICAL PARAMETERS, PARAMETERS FOR THE SPA-   %
%    TIAL AND TEMPORAL RESOLUTION AND OTHER COMPUTAIONAL PARAMETERS.      %
%=========================================================================%

% Define fundamental dimensionless parameters
kh       = 1;     % Fundamental wave number times water depth
relSteep = 0.60;  % Wave steepness relative to the maximum steepness
NPeriod  = 10;     % The number of periods for which the wave is propagated in time

% Define parameters related to the spatial resolution
Nx = 32;       % 2*Nx is the number of points used in the x direction
Ny = 1;        % 2*Ny is the number of points used in the y direction
Ns = 20;       % Ns+1 is the number of points used in the vertical dimension

% Define parameters related to the temporal resolution
NStep = 100;   % The number of time steps every period

% Define parameters related to the damping strategy
dampStrat = 2;        % The damping stratety. If dampStrat = 1: No damping. If dampStrat = 2: Damp ynew in rk4Step
dampCoef  = 0.7;      % The damping coefficient. A Fourier coefficient of ynew is set to 0 if |k|/|kMax| <= dampCoef

% Define other computational parameters
NSSGW    = 10000;     % The number of Fourier modes used by the SSGW routine
epsGMRES = 1E-9;     % The relative tolerance to which the linear system for the potential is solved

%=========================================================================%
% 3) DEFINE PHYSICAL PARAMETERS IN SI UNITS AND DEFINE GLOBAL VARIABLES.  %
%=========================================================================%

% Define fundamental physical scales
lambda = 2*pi;    % Wavelength
g      = 9.81;    % Gravitational acceleration

% Calculate relevant physical scales
Lx    = lambda;                           % Domain length in the x direction
Ly    = lambda;                           % Domain length in the y direction
h     = Lx/(2*pi)*kh;                     % Water depth
steep = 0.1401*tanh(0.8863*kh)*relSteep;  % Actual wave steepness (H/lambda) as given by Battjes


% Define global variables used for time integration. NOTE: These variables
% are only manipulated in mainProgram.m and compws.m!
global maxIter        % The maximum number of GMRES iterations allowed 
global iterCoef       % The maximum number of iterations at is computed as maxIter(n+1) = iterCoef*iter(n)
global Fold           % Fold contains the three most recent solutions to the Laplace problem

%=========================================================================%
% 4) INITIALIZE y AND COMPUTE b AND THE TIME STEP.                        %
%=========================================================================%

% Initialize y0 and T and compute b and the time step
[y0, T] = initializeSNW(h, Lx, g, steep, Nx, Ny, NSSGW);
b      = max(abs(y0(1:2*Nx*2*Ny)));
deltat = T/NStep;


%=========================================================================%
% 5) CONSTRUCT TIME INDEPENDENT MATRICES AND VECTORS FOR DIFFERENTIATION  %
%    AND PRECONDITIONING.                                                 %
%=========================================================================%

% Construct derivative vectors for the x direction
Dx1 = 1i*2*pi/Lx*[transpose(0:Nx-1); 0; transpose(-Nx+1:-1)];
Dx2 = -(2*pi/Lx*[transpose(0:Nx); transpose(-Nx+1:-1)]).^2;
    
% Construct derivative vectors for the y direction
Dy1 = 1i*2*pi/Ly*[0:Ny-1, 0, -Ny+1:-1];
Dy2 = -(2*pi/Ly*[0:Ny, -Ny+1:-1]).^2;
    
% Construct the differentiation matrices for the vertical direction
sGrid  = JacobiGL(0 ,0, Ns);
s1Vec  = transpose(1 + sGrid);
s1Vec2 = s1Vec.^2; 
[Ds1, Ds2] = compLegendreDerivMat(Ns, sGrid);

% Construct KMat, TMat, DMat and the LU decomposition of the preconditioner
[KMat, TMat, DMat] = compKMatTMatDMat(Nx, Ny, Lx, Ly, h, b, dampCoef);
[decompL, decompU, decompP] = compLUPrecon(Nx, Ny, Ns, Ds1, Ds2, KMat, transpose(TMat), b);


%=========================================================================%
% 6) CARRY OUT THE TIME INTEGRATION.                                      %
%=========================================================================%

% Initialize global variables
maxIter  = 20;
iterCoef = 1.1;
Fold     = zeros(2*Nx*2*Ny*(Ns+1), 3);

% Perform the time integration
y = y0;
for nt = 1:NPeriod*NStep
    % Print the time in units of wave periods
    t = nt/NStep
       
    % Advance y one time step
    y = rk4Step(y, deltat, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, s1Vec, s1Vec2, b, g, epsGMRES, ...
                decompL, decompU, decompP, dampStrat, DMat);

    % Animate the surface elevation
    figure(1)
    surf((0:2*Ny-1), (0:2*Nx-1), reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]))
    axis([0 (2*Ny-1) 0 (2*Nx-1) -2*max(y0(1:2*Nx)) 2*max(y0(1:2*Nx))])
    view(-150,20)
end

% Print the result of the compuation to file
dlmwrite(['OutputData/y0Steep', num2str(100*relSteep), 'kh', num2str(100*kh), 'NPeriod', num2str(NPeriod), ...
          'NStep', num2str(NStep), 'Nx', num2str(Nx), 'Ny', num2str(Ny), 'Ns', num2str(Ns)], ...
          y0, 'precision','%.15f')
dlmwrite(['OutputData/ySteep', num2str(100*relSteep), 'kh', num2str(100*kh), 'NPeriod', num2str(NPeriod), ...
          'NStep', num2str(NStep), 'Nx', num2str(Nx), 'Ny', num2str(Ny), 'Ns', num2str(Ns)], ...
          y, 'precision','%.15f')
dlmwrite(['OutputData/periodSteep', num2str(100*relSteep), 'kh', num2str(100*kh), 'NPeriod', num2str(NPeriod), ...
          'NStep', num2str(NStep), 'Nx', num2str(Nx), 'Ny', num2str(Ny), 'Ns', num2str(Ns)], ...
          T, 'precision','%.15f')
