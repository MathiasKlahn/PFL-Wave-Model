clc; close all; clear all;

%=========================================================================%
% 1) ADD DIRECTORIES TO THE SEARCH PATH.                                  %
%=========================================================================%

% Add the source directory to the search path
addpath('')

%=========================================================================%
% 2) DEFINE NONDIMENSIONAL PHYSICAL PARAMETERS, PARAMETERS FOR THE SPA-   %
%    TIAL AND TEMPORAL RESOLUTION AND OTHER COMPUTAIONAL PARAMETERS.      %
%=========================================================================%

% Define fundamental dimensionless parameters
kh       = 1;     % Fundamental wave number times water depth
relSteep = 0.80;  % Wave steepness relative to the maximum steepness
NPeriod  = 10;     % The number of periods for which the wave is propagated in time
xPos     = 0.25;   % The x position (in units of wavelength) at which the velocity profiles are computed
yPos     = 0.37;   % The y position (in units of wavelength) at which the velocity profiles are computed

% Define parameters related to the spatial resolution
Nx = 32;       % 2*Nx is the number of points used in the x direction
Ny = 1;        % 2*Ny is the number of points used in the y direction
Ns = 20;       % Ns+1 is the number of points used in the vertical dimension

% Define parameters related to the temporal resolution
NStep = 100;   % The number of time steps every period

% Define parameters related to the damping strategy
dampStrat = 2;        % The damping stratety. If dampStrat = 1: No damping. If dampStrat = 2: Damp ynew in rk4Step
dampCoef  = 0.7;      % The damping coefficient. A Fourier coefficient of ynew is set to 0 if |k|/|kMax| <= dampCoef

% Define other computational parameters
NSSGW    = 10000;     % The number of Fourier modes used by the SSGW routine
epsGMRES = 1E-9;     % The relative tolerance to which the linear system for the potential is solved

%=========================================================================%
% 3) DEFINE PHYSICAL PARAMETERS IN SI UNITS AND DEFINE GLOBAL VARIABLES.  %
%=========================================================================%

% Define fundamental physical scales
lambda = 2*pi;    % Wavelength
g      = 9.81;    % Gravitational acceleration

% Calculate relevant physical scales
Lx    = lambda;                           % Domain length in the x direction
Ly    = lambda;                           % Domain length in the y direction
h     = Lx/(2*pi)*kh;                     % Water depth
steep = 0.1401*tanh(0.8863*kh)*relSteep;  % Actual wave steepness (H/lambda) as given by Battjes
Hmax  = 0.1401*tanh(0.8863*kh)*lambda;    % The maximum wave height as given by Battjes

%=========================================================================%
% 4) LOAD y, y0 AND THE WAVE PERIOD FROM FILE AND COMPUTE b.              %
%=========================================================================%

% Initialize y0 and T and compute b and the time step
y  = dlmread(['OutputData/y0Steep', num2str(100*relSteep), 'kh', num2str(100*kh), 'NPeriod', num2str(NPeriod), ...
          'NStep', num2str(NStep), 'Nx', num2str(Nx), 'Ny', num2str(Ny), 'Ns', num2str(Ns)]);
y0 = dlmread(['OutputData/ySteep', num2str(100*relSteep), 'kh', num2str(100*kh), 'NPeriod', num2str(NPeriod), ...
          'NStep', num2str(NStep), 'Nx', num2str(Nx), 'Ny', num2str(Ny), 'Ns', num2str(Ns)]);
T  = dlmread(['OutputData/periodSteep', num2str(100*relSteep), 'kh', num2str(100*kh), 'NPeriod', num2str(NPeriod), ...
          'NStep', num2str(NStep), 'Nx', num2str(Nx), 'Ny', num2str(Ny), 'Ns', num2str(Ns)])
      
b = max(abs(y0(1:2*Nx*2*Ny)));

%=========================================================================%
% 5) CONSTRUCT TIME INDEPENDENT MATRICES AND VECTORS FOR DIFFERENTIATION  %
%    AND PRECONDITIONING.                                                 %
%=========================================================================%

% Construct derivative vectors for the x direction
Dx1 = 1i*2*pi/Lx*[transpose(0:Nx-1); 0; transpose(-Nx+1:-1)];
Dx2 = -(2*pi/Lx*[transpose(0:Nx); transpose(-Nx+1:-1)]).^2;
    
% Construct derivative vectors for the y direction
Dy1 = 1i*2*pi/Ly*[0:Ny-1, 0, -Ny+1:-1];
Dy2 = -(2*pi/Ly*[0:Ny, -Ny+1:-1]).^2;
    
% Construct the differentiation matrices for the vertical direction
sGrid  = JacobiGL(0 ,0, Ns);
s1Vec  = transpose(1 + sGrid);
s1Vec2 = s1Vec.^2; 
[Ds1, Ds2] = compLegendreDerivMat(Ns, sGrid);

% Construct KMat, TMat, DMat and the LU decomposition of the preconditioner
[KMat, TMat, DMat] = compKMatTMatDMat(Nx, Ny, Lx, Ly, h, b, dampCoef);
[decompL, decompU, decompP] = compLUPrecon(Nx, Ny, Ns, Ds1, Ds2, KMat, transpose(TMat), b);


%=========================================================================%
% 6) COMPARE THE FINAL STATE TO THE INITIAL STATE.                        %
%=========================================================================%

% Construct the equidistant grid for the x direction in SI units
xGrid = lambda*(0:2*Nx-1)/(2*Nx);

% Compare surface elevation of the final state to the initial state
figure(1)
plot(xGrid/lambda, y0(1:2*Nx)/Hmax, '-', 'LineWidth', 2)
hold on
plot(xGrid/lambda, y(1:2*Nx)/Hmax, 'o', 'LineWidth', 2)

set(gca, 'FontSize', 16)
set(gca, 'TickLabelInterpreter', 'latex')
set(gca, 'position', [0.16, 0.16, 0.80, 0.80])
   
xlabel('$x/\lambda$', 'interpreter', 'latex', 'FontSize', 22)
ylabel('$\eta/H_\mathrm{max}$', 'interpreter', 'latex', 'FontSize', 22)

legend1 = legend('Initial', 'Final')
set(legend1, 'Interpreter', 'latex', 'FontSize', 16)


%=========================================================================%
% 7) COMPUTE VELOCITY PROFILES.                                           %
%=========================================================================%

% Extract the surface elevation at the desired x position
eta    = reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]);
etaPos = real(sum(sum(1/(2*Nx*2*Ny)*fft2(eta).*exp(Dx1*(xPos*lambda)+Dy1*(yPos*lambda)))));

% Construct grid for the z-direction in SI units
zGrid = [linspace(-h, etaPos, 209)];

% Compute the velocity profiles
[uProfile, vProfile, wProfile] = compVelProfile(y, zGrid, sGrid, xPos*lambda, yPos*lambda, h, b, ...
                                                Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2,KMat, TMat, ...
                                                s1Vec, s1Vec2, epsGMRES, decompL, decompU, decompP);

% Calculate the nonlinear phase velocity
cNonlinear = lambda/T;
                                  
% Plot the result of the calculation
figure(2)
plot(uProfile/cNonlinear, zGrid/h, 'LineWidth', 2)
hold on
plot(vProfile/cNonlinear, zGrid/h, 'LineWidth', 2)
plot(wProfile/cNonlinear, zGrid/h, 'LineWidth', 2)

set(gca, 'FontSize', 16)
set(gca, 'TickLabelInterpreter', 'latex')
set(gca, 'position', [0.16, 0.16, 0.80, 0.80])
   
xlabel('$u/c, v/c, w/c$', 'interpreter', 'latex', 'FontSize', 22)
ylabel('$z/h$', 'interpreter', 'latex', 'FontSize', 22)

legend1 = legend('$u$', '$v$', '$w$')
set(legend1, 'Interpreter', 'latex', 'FontSize', 16, 'Location', 'southeast')
