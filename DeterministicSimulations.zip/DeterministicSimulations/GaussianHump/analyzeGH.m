clc; close all; clear all;

%=========================================================================%
% 1) ADD DIRECTORIES TO THE SEARCH PATH.                                  %
%=========================================================================%

% Add the source directory to the search path
addpath('')

%=========================================================================%
% 2) DEFINE NONDIMENSIONAL PHYSICAL PARAMETERS, PARAMETERS FOR THE SPA-   %
%    TIAL AND TEMPORAL RESOLUTION AND OTHER COMPUTAIONAL PARAMETERS.      %
%=========================================================================%

% Define fundamental dimensionless parameters
hTilde     = 1;         % Water depth in units of L
sigmaTilde = 0.02;      % Characteristic width of the gaussian hump in units of L
HTilde     = 2^(-6);    % Height of the gaussian hump in units of L
NPeriod    = 10;         % Time in units of T0 for which the system is integrated in time

% Define parameters related to the spatial resolution
Nx = 64;       % The number of points in the x direction is 2*Nx
Ny = 64;       % The number of points in the y direction is 2*Ny
Ns = 10;       % Ns+1 is the number of points used in the vertical dimension

% Define parameters related to the temporal resolution
NStep = 5;      % The number of time steps every fundamental time unit

% Define parameters related to the damping strategy
dampStrat = 1;        % The damping stratety. If dampStrat = 1: No damping. If dampStrat = 2: Damp ynew in rk4Step
dampCoef  = 0.7;      % The damping coefficient. A Fourier coefficient of ynew is set to 0 if |k|/|kMax| <= dampCoef

% Define other computational parameters
epsGMRES  = 1E-9;     % The relative tolerance to which the linear system for the potential is solved


%=========================================================================%
% 3) DEFINE PHYSICAL PARAMETERS IN SI UNITS AND DEFINE GLOBAL VARIABLES.  %
%=========================================================================%

% Define fundamental physical scales
L = 2*pi;    % Domain size in each of the horizontal dimensions
g = 9.81;    % Gravitational acceleration

% Calculate all other physical scales
Lx    = L;                 % Domain length in the x direction
Ly    = L;                 % Domain length in the y direction
h     = hTilde*L;          % Water depth
sigma = sigmaTilde*L;      % Deviation of the gaussian hump
H     = HTilde*L;          % Height of the gaussian hump 
T0    = sigma/sqrt(g*h);   % Fundamental unit of time

%=========================================================================%
% 4) LOAD RESULTS FROM FILE AND PLOT THEM.                                %
%=========================================================================%

% Load the results from file
centerElevation = dlmread(['OutputData/centerElevationNPeriod', num2str(NPeriod), 'NStep', num2str(NStep), ...
          'Nx', num2str(Nx), 'Ny', num2str(Ny), 'Ns', num2str(Ns)]);
time = dlmread(['OutputData/timeNPeriod', num2str(NPeriod), 'NStep', num2str(NStep), ...
          'Nx', num2str(Nx), 'Ny', num2str(Ny), 'Ns', num2str(Ns)]);

% Plot the time evolution of the centerelevation
figure(1)
plot(time, centerElevation, 'LineWidth', 2)

set(gca, 'FontSize', 16)
set(gca, 'TickLabelInterpreter', 'latex')
set(gca, 'position', [0.18, 0.18, 0.78, 0.78])

xlabel('$t \big/ \big( \sigma / (gh)^{1/2} \big)$', 'Interpreter', 'latex', 'FontSize', 22)
ylabel('$\eta(L/2, L/2, t)/H$', 'Interpreter', 'latex', 'FontSize', 22)

