clc; close all; clear all;

%=========================================================================%
% 1) ADD DIRECTORIES TO THE SEARCH PATH.                                  %
%=========================================================================%

% Add the source directory to the search path
addpath('')

%=========================================================================%
% 2) DEFINE NONDIMENSIONAL PHYSICAL PARAMETERS, PARAMETERS FOR THE SPA-   %
%    TIAL AND TEMPORAL RESOLUTION AND OTHER COMPUTAIONAL PARAMETERS.      %
%=========================================================================%

% Define fundamental dimensionless parameters
hTilde     = 1;         % Water depth in units of L
sigmaTilde = 0.02;      % Characteristic width of the gaussian hump in units of L
HTilde     = 2^(-6);    % Height of the gaussian hump in units of L
NPeriod    = 10;         % Time in units of T0 for which the system is integrated in time

% Define parameters related to the spatial resolution
Nx = 64;       % The number of points in the x direction is 2*Nx
Ny = 64;       % The number of points in the y direction is 2*Ny
Ns = 10;       % Ns+1 is the number of points used in the vertical dimension

% Define parameters related to the temporal resolution
NStep = 5;      % The number of time steps every fundamental time unit

% Define parameters related to the damping strategy
dampStrat = 1;        % The damping stratety. If dampStrat = 1: No damping. If dampStrat = 2: Damp ynew in rk4Step
dampCoef  = 0.7;      % The damping coefficient. A Fourier coefficient of ynew is set to 0 if |k|/|kMax| <= dampCoef

% Define other computational parameters
epsGMRES  = 1E-9;     % The relative tolerance to which the linear system for the potential is solved

%=========================================================================%
% 3) DEFINE PHYSICAL PARAMETERS IN SI UNITS AND DEFINE GLOBAL VARIABLES.  %
%=========================================================================%

% Define fundamental physical scales
L = 2*pi;    % Domain size in each of the horizontal dimensions
g = 9.81;    % Gravitational acceleration

% Calculate all other physical scales
Lx    = L;                 % Domain length in the x direction
Ly    = L;                 % Domain length in the y direction
h     = hTilde*L;          % Water depth
sigma = sigmaTilde*L;      % Deviation of the gaussian hump
H     = HTilde*L;          % Height of the gaussian hump 
T0    = sigma/sqrt(g*h);   % Fundamental unit of time

% Define global variables used for time integration. NOTE: These variables
% are only manipulated in mainProgram.m and compws.m!
global maxIter        % The maximum number of GMRES iterations allowed 
global iterCoef       % The maximum number of iterations at is computed as maxIter(n+1) = iterCoef*iter(n)
global Fold           % Fold contains the three most recent solutions to the Laplace problem

%=========================================================================%
% 4) INITIALIZE y AND COMPUTE b AND THE TIME STEP.                        %
%=========================================================================%

% Initialize y and compute b and deltat
y      = initializeGH(Nx, Ny, L, H, sigma);
b      = 1*max(abs(y(1:2*Nx*2*Ny)));
deltat = T0/NStep;

%=========================================================================%
% 5) CONSTRUCT TIME INDEPENDENT MATRICES AND VECTORS FOR DIFFERENTIATION  %
%    AND PRECONDITIONING.                                                 %
%=========================================================================%

% Construct derivative vectors for the x direction
Dx1 = 1i*2*pi/Lx*[transpose(0:Nx-1); 0; transpose(-Nx+1:-1)];
Dx2 = -(2*pi/Lx*[transpose(0:Nx); transpose(-Nx+1:-1)]).^2;

% Construct derivative vectors for the y direction
Dy1 = 1i*2*pi/Ly*[0:Ny-1, 0, -Ny+1:-1];
Dy2 = -(2*pi/Ly*[0:Ny, -Ny+1:-1]).^2;

% Construct the differentiation matrices for the vertical direction
sGrid  = JacobiGL(0 ,0, Ns);
s1Vec  = transpose(1 + sGrid);
s1Vec2 = s1Vec.^2; 
[Ds1, Ds2] = compLegendreDerivMat(Ns, sGrid);

% Construct KMat, TMat, DMat and the LU decomposition of the preconditioner
[KMat, TMat, DMat] = compKMatTMatDMat(Nx, Ny, L, L, h, b, dampCoef);
[decompL, decompU, decompP] = compLUPrecon(Nx, Ny, Ns, Ds1, Ds2, KMat, transpose(TMat), b);

%=========================================================================%
% 6) CARRY OUT THE TIME INTEGRATION.                                      %
%=========================================================================%

% Initialize global variables
maxIter  = 20;
iterCoef = 1.2;
Fold     = zeros(2*Nx*2*Ny*(Ns+1), 3);

% construct the matrix needed for the evaluation of eta at (x,y) = L/2*(1,1)
signMat = zeros(2*Nx,2*Ny);
nxList  = [0:Nx, -Nx+1:-1];
nyList  = [0:Ny, -Ny+1:-1];
for nx = 1:2*Nx
    for ny = 1:2*Ny
        signMat(nx,ny) = (-1)^(nx+ny);
    end
end

% Allocate arrays for the surface elevation at (x,y) = L/2*(1,1) (i.e. the
% center elevation) and the time
centerElevation = zeros(NStep*NPeriod+1,1);
time            = zeros(NStep*NPeriod+1,1);
        
for nt = 1:NStep*NPeriod+1
    % Evaulate the surface elevation at (x,y) = L/2*(1,1) in units of H and
    % monitor the time in units of T0
    centerElevation(nt) = real(sum(sum(1/(2*Nx*2*Ny)*fft2(reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny])).*signMat)))/H;
    time(nt)            = (nt-1)/NStep;
    
    % Print out the time in units of T0
    t = (nt-1)/NStep
       
    % Advance y one time step
    y = rk4Step(y, deltat, Nx, Ny, Ns, Dx1, Dx2, Dy1, Dy2, Ds1, Ds2, TMat, s1Vec, s1Vec2, b, g,...
                epsGMRES, decompL, decompU, decompP, dampStrat, DMat);
    
    % Animate the surface elevation
    figure(1)
    surf(1:2*Nx, 1:2*Ny, reshape(y(1:2*Nx*2*Ny), [2*Nx, 2*Ny]))
    axis([0 2*Ny 0 2*Nx -2*H 2*H])
end

% Write the result of the compuation to file
dlmwrite(['OutputData/centerElevationNPeriod', num2str(NPeriod), 'NStep', num2str(NStep), ...
          'Nx', num2str(Nx), 'Ny', num2str(Ny), 'Ns', num2str(Ns)], centerElevation, 'precision','%.15f')
dlmwrite(['OutputData/timeNPeriod', num2str(NPeriod), 'NStep', num2str(NStep), ...
          'Nx', num2str(Nx), 'Ny', num2str(Ny), 'Ns', num2str(Ns)], time, 'precision','%.15f')

